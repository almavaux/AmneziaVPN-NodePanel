#!/usr/bin/env python3
"""
Test script to verify Amnezia config generation.
Tests both V1 (legacy) and V2 (awg2) config formats.
"""

import json
import sys
import os
from unittest.mock import Mock, patch

# Mock the docker_manager and settings before importing awg_manager
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "app"))

# Create mock docker manager
mock_docker = Mock()
mock_docker.read_file = Mock(return_value="")
mock_docker.write_file = Mock()
mock_docker.exec_run = Mock(return_value="")
mock_docker.exec_shell = Mock()

# Create mock settings
mock_settings = Mock()
mock_settings.dns = "1.1.1.1,1.0.0.1"
mock_settings.server_host = "example.com"

# Patch before importing
sys.modules["infrastructure.docker_manager"] = Mock(docker_manager=mock_docker)
sys.modules["core.config"] = Mock(settings=mock_settings)

# Set up patches
with patch("core.awg_manager.docker_manager", mock_docker), \
     patch("core.awg_manager.settings", mock_settings):
    
    # Now we can import the functions we're testing
    # We need to manually set the module state
    from core.awg_manager import (
        _build_amnezia_profile,
        _to_amnezia_vpn_link,
        _pick_h,
    )
    
    # Set the global mode the functions expect
    import core.awg_manager as awg_manager
    awg_manager._MODE = "legacy"  # Start with legacy mode


def test_legacy_config():
    """Test V1 (legacy) AmneziaWG config generation."""
    print("\n" + "="*70)
    print("TEST 1: LEGACY (V1) CONFIG GENERATION")
    print("="*70)
    
    iface = {
        "ListenPort": "51820",
        "Jc": "4",
        "Jmin": "50",
        "Jmax": "100",
        "S1": "87",
        "S2": "65",
        "S3": "0",
        "S4": "0",
        "H1": "1000000000-1000000010",
        "H2": "2000000000-2000000010",
        "H3": "3000000000-3000000010",
        "H4": "4000000000-4000000010",
        "I1": "<r 2><b 0x858000010001000000000669636c6f756403636f6d0000010001c00c000100010000105a00044d583737>",
    }
    
    profile_json = _build_amnezia_profile(
        client_name="TestUser-Legacy",
        client_private_key="2aYNl1S+aEZAJrECplslhSvZ8aZDzKVWfvXdP/gBfEY=",
        client_public_key="EGxNYihRLKQ9nvdOE5j5aZ7rtw3ttzJS1xxaJpgYYHI=",
        client_ip="10.0.0.2/32",
        server_pubkey="k5vZYvnGJzz5LaYfZxp1aZxZzzZ8aZ5LaYfZx3p1aZx=",
        psk="2OiSh6rP3t/g39jgJNGK70B+nize821yIFNtUqi8/XU=",
        iface=iface,
        interface_comments=[
            "# I1 = <r 2><b 0x858000010001000000000669636c6f756403636f6d0000010001c00c000100010000105a00044d583737>",
        ],
    )
    
    profile = json.loads(profile_json)
    
    # Verify structure
    print("\n✓ Profile structure OK")
    assert "containers" in profile
    assert len(profile["containers"]) == 1
    assert "awg" in profile["containers"][0]
    
    awg = profile["containers"][0]["awg"]
    
    # Verify all required AWG parameters are present
    required_params = ["Jc", "Jmin", "Jmax", "S1", "S2", "S3", "S4", "H1", "H2", "H3", "H4", "port", "transport_proto"]
    for param in required_params:
        assert param in awg, f"Missing parameter: {param}"
        print(f"  ✓ {param}: {awg[param]}")
    
    # Verify values are correct type
    assert isinstance(awg["Jc"], str), "Jc should be string in JSON"
    assert isinstance(awg["port"], str), "port should be string in JSON"
    assert awg["H1"] != "", "H1 should be sampled (not empty)"
    assert awg["H2"] != "", "H2 should be sampled (not empty)"
    
    # Verify last_config contains the client config
    assert "last_config" in awg
    last_config = awg["last_config"]
    assert "[Interface]" in last_config
    assert "[Peer]" in last_config
    assert "PrivateKey" in last_config
    assert "PublicKey" in last_config
    assert "PresharedKey" in last_config
    
    print("\n✓ Last_config content OK")
    print("Config preview:")
    print(last_config[:300] + "...")
    
    # Test VPN link generation
    vpn_link = _to_amnezia_vpn_link(profile_json)
    assert vpn_link.startswith("vpn://"), "VPN link should start with vpn://"
    print(f"\n✓ VPN link generated: {vpn_link[:50]}...")
    
    print("\n✓ LEGACY CONFIG TEST PASSED")
    return True


def test_new_config():
    """Test V2 (AWG2) config generation."""
    print("\n" + "="*70)
    print("TEST 2: NEW (V2) AWG2 CONFIG GENERATION")
    print("="*70)
    
    iface = {
        "ListenPort": "51820",
        "Jc": "5",
        "Jmin": "50",
        "Jmax": "150",
        "S1": "15",
        "S2": "18",
        "S3": "20",
        "S4": "25",
        "H1": "123456-123500",
        "H2": "67543-67550",
        "H3": "123123-123200",
        "H4": "32345-32350",
    }
    
    profile_json = _build_amnezia_profile(
        client_name="TestUser-New",
        client_private_key="uIZe7BIQyPadbdJVbjKQqx9nHCq8bLH1E2VX4eIDT0E=",
        client_public_key="YQa7BIQyPadbdJVbjKQqx9nHCq8bLH1E2VX4eIDJHY4=",
        client_ip="10.0.0.3/32",
        server_pubkey="k5vZYvnGJzz5LaYfZxp1aZxZzzZ8aZ5LaYfZx3p1aZx=",
        psk="3PjTh7sQ4u/h40khKNLh81C/ojz0932zJGOuVRj9/YV=",
        iface=iface,
        interface_comments=[],
    )
    
    profile = json.loads(profile_json)
    
    # Verify structure
    print("\n✓ Profile structure OK")
    assert profile["defaultContainer"] == "amnezia-awg2"
    
    awg = profile["containers"][0]["awg"]
    
    # Verify all S parameters are present including S3/S4
    assert awg["S3"] is not None, "S3 should be present"
    assert awg["S4"] is not None, "S4 should be present"
    print(f"  ✓ S3: {awg['S3']}")
    print(f"  ✓ S4: {awg['S4']}")
    
    # Verify H values are sampled integers (not ranges)
    try:
        h1_val = int(awg["H1"])
        assert 123456 <= h1_val <= 123500, f"H1 should be in range, got {h1_val}"
        print(f"  ✓ H1 sampled correctly: {h1_val}")
    except ValueError:
        raise AssertionError(f"H1 should be integer, got: {awg['H1']}")
    
    print("\n✓ NEW CONFIG TEST PASSED")
    return True


def test_minimal_config():
    """Test with minimal parameters (no S3/S4, no I1-I5)."""
    print("\n" + "="*70)
    print("TEST 3: MINIMAL CONFIG (standard WG + basic AWG params)")
    print("="*70)
    
    iface = {
        "ListenPort": "51820",
        "Jc": "0",
        "Jmin": "0",
        "Jmax": "0",
        "S1": "0",
        "S2": "0",
        "S3": "0",
        "S4": "0",
    }
    
    profile_json = _build_amnezia_profile(
        client_name="TestUser-Minimal",
        client_private_key="cJZf8CIRyPdhfJWdiLRprYzp0IDv9MI2G3WY5gBDX1E=",
        client_public_key="aQb8CIRyPdhfJWdiLRprYzp0IDv9MI2G3WY5gBDJKY5=",
        client_ip="10.0.0.4/32",
        server_pubkey="k5vZYvnGJzz5LaYfZxp1aZxZzzZ8aZ5LaYfZx3p1aZx=",
        psk="4QkUi8tR5v/i51liLOMl92D/pkA1933zKHPvWSk/+ZW=",
        iface=iface,
        interface_comments=[],
    )
    
    profile = json.loads(profile_json)
    awg = profile["containers"][0]["awg"]
    
    # Should not have H1-H4 since they weren't in iface
    # but should have S1-S4 (as "0")
    print(f"  ✓ S1: {awg['S1']}")
    print(f"  ✓ S2: {awg['S2']}")
    print(f"  ✓ S3: {awg['S3']}")
    print(f"  ✓ S4: {awg['S4']}")
    
    # Verify config generation
    last_config = awg["last_config"]
    assert "Address = 10.0.0.4" in last_config
    print(f"\n  ✓ Config contains correct client IP")
    
    print("\n✓ MINIMAL CONFIG TEST PASSED")
    return True


if __name__ == "__main__":
    try:
        test_legacy_config()
        test_new_config()
        test_minimal_config()
        
        print("\n" + "="*70)
        print("ALL TESTS PASSED ✓")
        print("="*70)
        sys.exit(0)
    except Exception as e:
        print(f"\n✗ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
