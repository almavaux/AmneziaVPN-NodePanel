#!/usr/bin/env bash
# Single public entrypoint for AWG setup workflows.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
  cat <<EOF
Usage:
  ./setup.sh                        # interactive installer (master/node local/remote)
  ./setup.sh from-zip --zip <PATH> [--target-dir <PATH>] [--skip-build] [--mode update|clean-reinstall]

Notes:
  - This is the only public setup entrypoint.
  - Other scripts in scripts/ are internal implementation details.
  - update (default): preserves .env and state/ (keys, PKI, node bindings).
  - clean-reinstall: removes state and runtime env, then installs from scratch.
EOF
}

if [ $# -eq 0 ]; then
  exec bash "$ROOT_DIR/scripts/setup.sh"
fi

case "$1" in
  from-zip)
    shift
    exec bash "$ROOT_DIR/scripts/install_from_zip.sh" "$@"
    ;;
  -h|--help|help)
    usage
    ;;
  *)
    echo "Unknown command: $1" >&2
    usage
    exit 1
    ;;
esac
