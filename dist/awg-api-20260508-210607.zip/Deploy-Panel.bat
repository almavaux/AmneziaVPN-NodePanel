@echo off
REM Deploy-Panel.bat - Batch wrapper for PowerShell deployment script
setlocal enabledelayedexpansion

if "%1"=="" (
    echo.
    echo Deploy Panel to Server
    echo.
    echo Usage:
    echo   Deploy-Panel.bat [ServerIP] [Mode] [SSHKey]
    echo.
    echo Parameters:
    echo   ServerIP    - Server IP address (optional - will be prompted if not provided)
    echo   Mode        - Deployment mode: update or clean-install (optional - will be prompted if not provided)
    echo   SSHKey      - Path to SSH private key (optional - will be auto-detected if not provided)
    echo.
    echo Examples:
    echo   Deploy-Panel.bat 192.168.1.100
    echo   Deploy-Panel.bat 192.168.1.100 update
    echo   Deploy-Panel.bat 192.168.1.100 clean-install "C:\Users\User\.ssh\id_rsa"
    echo.
    pause
    call powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Deploy-Panel.ps1"
    exit /b !errorlevel!
)

set ServerIP=%1
set Mode=%2
set SSHKey=%3

if not "!SSHKey!"=="" (
    call powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Deploy-Panel.ps1" -ServerIP "!ServerIP!" -Mode "!Mode!" -SSHKey "!SSHKey!"
) else if not "!Mode!"=="" (
    call powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Deploy-Panel.ps1" -ServerIP "!ServerIP!" -Mode "!Mode!"
) else (
    call powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Deploy-Panel.ps1" -ServerIP "!ServerIP!"
)

exit /b !errorlevel!
