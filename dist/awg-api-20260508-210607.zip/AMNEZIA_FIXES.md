# Исправления генерации конфигов Amnezia (v1 legacy и v2)

## Проблема

Ваш код генерировал неверный конфиг для пользователей Amnezia VPN. При сравнении с официальными репозиториями (`amneziawg-go` и `amneziawg-linux-kernel-module`) выявлены 5 критических ошибок.

## Найденные ошибки в `awg_manager.py`

### ❌ Ошибка #1: S3/S4 отсутствуют в protocol_payload 
**Местоположение:** Строки 427-428 (старый код)

**Проблема:** Параметры S3 и S4 добавлялись условно ПОСЛЕ создания словаря protocol_payload, что могло привести к их отсутствию в финальном JSON.

```python
# БЫЛО (неправильно):
protocol_payload = {
    "H1": ...,
    "S1": client_payload["S1"],
    "S2": client_payload["S2"],
    "last_config": ...,  # S3/S4 не здесь!
}
if "S3" in client_payload:
    protocol_payload["S3"] = client_payload["S3"]
if "S4" in client_payload:
    protocol_payload["S4"] = client_payload["S4"]
```

**ИСПРАВЛЕНО:** S3 и S4 теперь всегда в основном словаре

```python
# СТАЛО (правильно):
protocol_payload = {
    "H1": client_payload.get("H1", ""),
    "H2": client_payload.get("H2", ""),
    "S1": client_payload["S1"],
    "S2": client_payload["S2"],
    "S3": client_payload["S3"],  # Всегда здесь
    "S4": client_payload["S4"],  # Всегда здесь
    "last_config": ...,
}
```

---

### ❌ Ошибка #2: Пустые значения параметров вместо нулей
**Местоположение:** Строки 372-375

**Проблема:** Когда параметр Jc/Jmin/Jmax не установлен, он становился пустой строкой `""` вместо `"0"`, что нарушает парсинг конфига.

```python
# БЫЛО (неправильно):
"Jc": str(iface.get("Jc", "")),      # Пустая строка!
"Jmax": str(iface.get("Jmax", "")),
"Jmin": str(iface.get("Jmin", "")),
```

**ИСПРАВЛЕНО:**
```python
# СТАЛО (правильно):
"Jc": str(iface.get("Jc", "0")),     # Значение по умолчанию = 0
"Jmax": str(iface.get("Jmax", "0")),
"Jmin": str(iface.get("Jmin", "0")),
"S3": str(iface.get("S3", "0")),     # Добавлены S3/S4
"S4": str(iface.get("S4", "0")),
```

---

### ❌ Ошибка #3: S3/S4 отсутствуют в начальной инициализации client_payload
**Местоположение:** Строки 361-389

**Проблема:** S3 и S4 не были в основной инициализации client_payload, что вызывало их отсутствие когда параметры были на уровне по умолчанию.

```python
# БЫЛО (неправильно):
client_payload = {
    ...
    "S1": str(iface.get("S1", "")),
    "S2": str(iface.get("S2", "")),
    # S3 и S4 добавляются только если есть в iface
}
if "S3" in iface:
    client_payload["S3"] = str(iface["S3"])
if "S4" in iface:
    client_payload["S4"] = str(iface["S4"])
```

**ИСПРАВЛЕНО:** Они теперь всегда присутствуют
```python
# СТАЛО (правильно):
client_payload = {
    ...
    "S1": str(iface.get("S1", "0")),
    "S2": str(iface.get("S2", "0")),
    "S3": str(iface.get("S3", "0")),    # Всегда!
    "S4": str(iface.get("S4", "0")),    # Всегда!
    ...
}
```

---

### ❌ Ошибка #4: I1-I5 параметры добавляются даже если пустые
**Местоположение:** Строки 396-399

**Проблема:** Пустые строки для I1-I5 добавлялись в конфиг файл, загромождая его ненужными строками.

```python
# БЫЛО (неправильно):
for key in ("I1", "I2", "I3", "I4", "I5"):
    raw_lines.append(f"{key} = {client_payload[key]}")  # Даже если оно пусто!
```

**ИСПРАВЛЕНО:**
```python
# СТАЛО (правильно):
for key in ("I1", "I2", "I3", "I4", "I5"):
    value = client_payload.get(key, "")
    if value:  # Только если есть значение
        raw_lines.append(f"{key} = {value}")
```

---

### ❌ Ошибка #5: Нулевые значения параметров добавляются в конфиг WireGuard
**Местоположение:** Строка 391

**Проблема:** Когда параметр S1-S4 имеет значение `"0"` (по умолчанию отключен), он всё равно добавлялся в конфиг, создавая redundancy.

```python
# БЫЛО (неправильно):
for key in ("Jc", "Jmin", "Jmax", "S1", "S2", "S3", "S4"):
    value = client_payload.get(key)
    if value:  # Добавляет даже "0"!
        raw_lines.append(f"{key} = {value}")
```

**ИСПРАВЛЕНО:**
```python
# СТАЛО (правильно):
for key in ("Jc", "Jmin", "Jmax", "S1", "S2", "S3", "S4"):
    value = client_payload.get(key)
    if value and value != "0":  # Пропускаем нулевые значения
        raw_lines.append(f"{key} = {value}")
```

---

## Резюме изменений

| Ошибка | Тип | Влияние | Статус |
|--------|------|--------|--------|
| S3/S4 в protocol_payload | Структура JSON | Критичное | ✅ Исправлено |
|默значения вместо нулей | Парсинг | Высокое | ✅ Исправлено |
| S3/S4 в client_payload | Инициализация | Критичное | ✅ Исправлено |
| Пустые I1-I5 | Чистота конфига | Среднее | ✅ Исправлено |
| Нулевые S параметры | Оптимизация | Низкое | ✅ Исправлено |

---

## Форматы конфигов Amnezia

### V1 (Legacy) - amnezia-awg (WireGuard-based)
Поддерживает стандартные параметры WireGuard + Amnezia обфускация:
- **Junk packets**: Jc (count), Jmin/Jmax (sizes)
- **Message padding**: S1, S2, S3, S4 (в байтах)
- **Header values**: H1-H4 (могут быть диапазон "x-y" или число)
- **Signature packets**: I1-I5 (кастомные пакеты перед handshake)

### V2 (AWG2) - amnezia-awg2 (новая версия)
Имеет те же параметры, но используется контейнер `amnezia-awg2` вместо `amnezia-awg`

---

## Проверка исправлений

Все исправления протестированы:
```
✓ Test 1: H-value sampling
✓ Test 2: Client payload structure  
✓ Test 3: Protocol payload structure
✓ Test 4: Config file generation
✓ Test 5: VPN link encoding

ALL TESTS PASSED ✓
```

---

## Файлы которые были исправлены

- [`app/core/awg_manager.py`](app/core/awg_manager.py) - 5 исправлений в функции `_build_amnezia_profile`

## Тесты

- [`test_config_simple.py`](test_config_simple.py) - Простые unit-тесты логики генерации
- [`test_config_generation.py`](test_config_generation.py) - Расширенные функциональные тесты (требует Docker)
