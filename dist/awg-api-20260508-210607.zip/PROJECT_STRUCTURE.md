# MAX Project Structure

Проект переорганизован для лучшей модульности и разделения ответственности.

## Основная структура

```
MAX/
├── app/                          # Основное приложение FastAPI
│   ├── main.py                   # Точка входа, инициализация FastAPI
│   ├── __init__.py
│   │
│   ├── api/                      # REST API слой
│   │   ├── __init__.py
│   │   ├── auth.py               # Аутентификация (API Key)
│   │   └── routers/              # API маршруты
│   │       ├── __init__.py
│   │       ├── users.py          # Управление пользователями (REST)
│   │       ├── nodes.py          # Управление узлами
│   │       ├── bootstrap.py      # Bootstrap процесс (Master/Node)
│   │       └── node_bootstrap.py # Bootstrap для Node
│   │
│   ├── core/                     # Основная бизнес-логика
│   │   ├── __init__.py
│   │   ├── awg_manager.py        # Управление AmneziaWG
│   │   ├── models.py             # Pydantic модели
│   │   ├── db.py                 # База данных (SQLAlchemy)
│   │   ├── config.py             # Конфигурация и settings
│   │   ├── identity.py           # Управление идентификацией узла
│   │   └── pki.py                # Управление сертификатами (PKI/CA)
│   │
│   ├── infrastructure/           # Инфраструктурные компоненты
│   │   ├── __init__.py
│   │   ├── docker_manager.py     # Управление Docker контейнерами
│   │   ├── ssh_executor.py       # Выполнение команд по SSH
│   │   ├── grpc_server.py        # gRPC сервер (управление узлами)
│   │   ├── grpc_client.py        # gRPC клиент
│   │   └── grpc/                 # Protocol Buffers определения
│   │       ├── __init__.py
│   │       ├── node.proto        # gRPC сервис определения
│   │       ├── node_pb2.py       # Скомпилированные protobuf
│   │       └── node_pb2_grpc.py  # Скомпилированные gRPC код
│   │
│   └── static/                   # Веб-панель (HTML/JS)
│       └── index.html            # Control panel UI
│
├── docker/                       # Docker конфигурация и deployment
│   ├── Dockerfile                # Docker образ приложения
│   ├── docker-compose.yml        # Docker Compose конфигурация
│   ├── deploy.sh                 # Скрипт деплоя
│   ├── .env.example              # Пример переменных окружения
│   ├── .env.deploy               # Production конфигурация
│   ├── .env.deploy.test          # Testing конфигурация
│   └── .env.legacy               # Legacy конфигурация
│
├── setup.sh                      # Единый публичный entrypoint установки
├── scripts/                      # Внутренние установочные и вспомогательные скрипты
│   ├── setup.sh                  # Интерактивный wizard (вызывается из ../setup.sh)
│   ├── install_project.sh        # Внутренний установщик проекта
│   ├── install_from_zip.sh       # Внутренняя обертка распаковки ZIP
│   └── install_node_remote.sh    # Единый внутренний скрипт удаленной установки Node
│
├── tests/                        # Тестовые скрипты
│   ├── test_api.sh               # Базовые тесты API
│   ├── test_api2.sh              # Дополнительные тесты API
│   ├── test_awg2.sh              # Тесты AWG
│   ├── test_awg_set.sh           # Тесты конфигурации
│   └── test_e2e.sh               # End-to-end тесты
│
├── .ssh-live/                    # SSH ключи (динамическое)
├── requirements.txt              # Python зависимости
├── README.md                     # Описание проекта
└── PROJECT_STRUCTURE.md          # Этот файл
```

## Слои приложения

### API Layer (`app/api/`)
Отвечает за REST API и эндпоинты:
- `auth.py` - валидация API Key из заголовков
- `routers/` - маршруты для различных ресурсов

### Core Layer (`app/core/`)
Основная бизнес-логика:
- `awg_manager.py` - основные операции с AmneziaWG (создание/удаление пользователя, получение конфига)
- `db.py` - модели и сессии базы данных
- `config.py` - загрузка и валидация конфигурации
- `models.py` - Pydantic модели для валидации
- `pki.py` - управление сертификатами и CA
- `identity.py` - управление идентификацией узла

### Infrastructure Layer (`app/infrastructure/`)
Низкоуровневые компоненты:
- `docker_manager.py` - работа с Docker SDK
- `ssh_executor.py` - выполнение команд по SSH на удалённых узлах
- `grpc_server.py` - gRPC сервер для управления узлами
- `grpc_client.py` - gRPC клиент для подключения к узлам
- `grpc/` - Protocol Buffers определения

## Архитектура

```
User Request
    ↓
FastAPI (main.py)
    ↓
API Routers (api/routers/)
    ↓
Core Logic (core/)
    ├→ Database (core/db.py)
    ├→ AWG Manager (core/awg_manager.py)
    ├→ PKI Manager (core/pki.py)
    └→ Identity Manager (core/identity.py)
    ↓
Infrastructure (infrastructure/)
    ├→ Docker Manager
    ├→ SSH Executor
    ├→ gRPC Server/Client
    └→ Config
```

## Развёртывание

```
Master Node:
  - REST API для управления узлами
  - gRPC сервер (с mTLS) для управления узлами
  - Веб-панель управления
  - Локальный CA для подписи сертификатов

Node:
  - REST API для локального управления пользователями
  - gRPC клиент зависит от случая
  - Получает команды от master через gRPC
  - Управляет локальным AmneziaWG контейнером
```

## Импорты

После переорганизации структуры, импорты работают следующим образом:

### Из main.py (app/):
```python
from .core.config import settings
from .core.awg_manager import detect_mode
from .infrastructure.docker_manager import docker_manager
from .api.routers.users import router as users_router
```

### Из API роутеров (app/api/routers/):
```python
from ..auth import require_api_key
from ...core.models import UserCreate
from ...infrastructure.ssh_executor import ssh_executor
```

### Из core модулей (app/core/):
```python
from .config import settings
from ..infrastructure.docker_manager import docker_manager
from .models import UserCreate
```

### Из infrastructure модулей (app/infrastructure/):
```python
from ..core.config import settings
from ..core.awg_manager import create_user
from .grpc import node_pb2
```

## Запуск

```bash
# Деплой
cd docker/
./deploy.sh

# Разработка
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
