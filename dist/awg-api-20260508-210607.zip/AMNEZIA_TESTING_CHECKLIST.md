# Чек-лист тестирования исправлений Amnezia

## ✅ Pre-flight Checks

Перед развертыванием исправлений убедитесь:

- [ ] Прочитаны AMNEZIA_FIXES.md и AMNEZIA_FORMAT_REFERENCE.md
- [ ] Запущены тесты `python test_config_simple.py` (все должны пройти)
- [ ] Код `app/core/awg_manager.py` обновлён на переиз версию
- [ ] Container docker с Amnezia запущен и доступен

---

## 🧪 Unit Tests (Локально)

```bash
# В репозитории MAX
python test_config_simple.py
```

**Должны пройти:**
- [ ] Test 1: H-value sampling
- [ ] Test 2: Client payload structure
- [ ] Test 3: Protocol payload structure
- [ ] Test 4: Config file generation
- [ ] Test 5: VPN link encoding

---

## 🔍 Integration Tests (With Docker)

### Тест 1: Создание пользователя

```bash
# На хосте с running API
curl -X POST http://localhost:8000/users \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"TestUser"}'
```

**Проверить в ответе:**
- [ ] `config` поле не пусто
- [ ] Начинается с `vpn://`
- [ ] `client_id` в формате base64url

### Тест 2: Скачивание конфіга

```bash
# Получи client_id из предыдущего запроса
curl http://localhost:8000/users/{client_id}/config \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -o test.vpn
```

**Проверить:**
- [ ] Файл не пустой
- [ ] Начинается с `vpn://`

### Тест 3: QR Code

```bash
curl http://localhost:8000/users/{client_id}/qr \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -o test.png
```

**Проверить:**
- [ ] Файл валидный PNG
- [ ] Размер > 1000 bytes

---

## 🔬 Config Validation (Manual)

### Декодирование vpn:// ссылки

```python
import base64
import zlib
import json

vpn_link = "vpn://..."  # Из конфига

# Извлеки token
token = vpn_link.replace("vpn://", "")

# Восстанови padding
token_padded = token + "=" * (4 - len(token) % 4)

# Декодируй base64url
packed = base64.urlsafe_b64decode(token_padded)

# Извлеки длину и распакуй
length = int.from_bytes(packed[:4], 'big')
compressed = packed[4:]
raw = zlib.decompress(compressed)

# Парси JSON
config = json.loads(raw.decode('utf-8'))

# Проверь структуру
print(json.dumps(config, indent=2))
```

**Должно содержать:**
- [ ] `containers[0].awg.S3` (не пусто)
- [ ] `containers[0].awg.S4` (не пусто)
- [ ] `containers[0].awg.last_config` (WireGuard конфіг)

### Проверка last_config

Из JSON конфига достань `containers[0].awg.last_config` и проверь:

```
[Interface]
Address = 10.0.0.X/32
DNS = ...
PrivateKey = ...
(Jc, Jmin, Jmax если > 0)
(S1, S2, S3, S4 если > 0)
(H1, H2, H3, H4 если есть)
(I1, I2, I3, I4, I5 только если не пусто)

[Peer]
PublicKey = ...
PresharedKey = ...
AllowedIPs = 0.0.0.0/0, ::/0
Endpoint = ...
PersistentKeepalive = 25
```

**Проверить:**
- [ ] Нет пустых параметров (I1 = пусто)
- [ ] Нет нулевых параметров (S1 = 0)
- [ ] S3/S4 присутствуют (или = 0)
- [ ] H1-H4 - числа, не диапазоны
- [ ] Правильный Endpoint (server_host:port)

---

## 🌍 Real-world Client Tests

### Тест на реальном клиенте Amnezia

1. **Выгенерируй конфиг для пользователя**
   - Используя исправленный API
   - Получи vpn:// ссылку или QR код

2. **Импортируй в Amnezia client**
   - Через QR код (мобиль)
   - Через копи-паста ссылки
   - Через импорт файла

3. **Проверь подключение**
   - [ ] Клиент подключается
   - [ ] IP адрес изменился (VPN активен)
   - [ ] Трафик есть в обе стороны
   - [ ] Нет ошибок в логах Amnezia

4. **Проверь обфускацию**
   - Должна быть активна согласно конфигу
   - Проверь статистику в клиенте (если доступна)

---

## 📊 Server-side Verification

### На хосте с running контейнером

```bash
# Проверь конфіг
docker exec <container_name> cat /opt/amnezia/awg/awg0.conf

# Должна быть структура:
# [Interface]
# Address = ...
# Jc = ...
# S1-S4 = ...
# H1-H4 = ...
# [Peer]
# ... для каждого пользователя
```

### Проверь clientsTable

```bash
docker exec <container_name> cat /opt/amnezia/awg/clientsTable | jq .
```

**Должна быть структура:**
```json
[
  {
    "clientId": "...",
    "userData": {
      "clientName": "...",
      "privateKey": "...",
      "presharedKey": "...",
      "allowedIps": "10.0.0.X/32",
      "creationDate": "..."
    }
  }
]
```

**Проверь:**
- [ ] `privateKey` присутствует
- [ ] `presharedKey` присутствует
- [ ] Все пользователи в конфигу есть в таблице

---

## 🚨 Регрессионные тесты

Убедись, что старые функции ещё работают:

### Список пользователей

```bash
curl http://localhost:8000/users \
  -H "Authorization: Bearer YOUR_API_KEY"
```

**Проверить:**
- [ ] Возвращает JSON список
- [ ] Каждый юзер имеет name, internal_ip, client_id
- [ ] Stats (transfer_rx/tx) если доступны

### Удаление пользователя

```bash
curl -X DELETE http://localhost:8000/users/{client_id} \
  -H "Authorization: Bearer YOUR_API_KEY"
```

**Проверить:**
- [ ] Возвращает 204 No Content
- [ ] Пользователь исчезает из списка
- [ ] Пользователь удаляется из clientsTable

---

## 📈 Performance Check

- [ ] Генерация конфига < 100ms
- [ ] QR код генерируется < 200ms
- [ ] API ответы в norm time

---

## 📝 Documentation Check

- [ ] AMNEZIA_FIXES.md прочитан и понят
- [ ] AMNEZIA_FORMAT_REFERENCE.md может использоваться как справочник
- [ ] test_config_simple.py может запуститься на чистом Python

---

## ✅ Sign-off

После прохождения всех тестов:

```
Дата тестирования: _______________
Тестер: _______________
Версия кода: _______________
Статус: ✅ ГОТОВО К PRODUCTION

Комментарии:
_____________________________________________
_____________________________________________
```

---

## 🆘 Troubleshooting

### Если тест 1-5 не проходит:
1. Проверь Python 3.8+
2. Проверь что `zlib` доступен
3. Запусти с `python -v` для отладки

### Если декодирование vpn:// не работает:
1. Проверь что паддинг base64 корректен
2. Проверь что zlib.decompress не выбрасывает исключение
3. Проверь что JSON валидный (`json.loads()`)

### Если конфиг не импортируется в Amnezia:
1. Проверь структуру JSON (должна быть идентична)
2. Проверь что все параметры в правильных типах (string/number)
3. Проверь что `containers.awg` имеет правильные ключи

---

**Версия чек-листа:** 1.0  
**Дата:** 2026-04-17
