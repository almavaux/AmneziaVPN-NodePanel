#!/usr/bin/env pwsh
# Deploy-Panel.ps1 - Panel deployment script for Windows
# Builds project ZIP and deploys AWG API panel to remote server

param(
    [string]$ServerIP = "",
    [string]$Mode = "",
    [string]$SSHKey = "",
    [int]$SSHPort = 22,
    [string]$User = "root",
    [string]$ProjectRoot = ""
)

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "Cyan"
    )
    Write-Host $Message -ForegroundColor $Color
}

function Write-Title {
    param([string]$Message)
    Write-Host ""
    Write-Host ("=" * 60) -ForegroundColor Cyan
    Write-ColorOutput ">>> $Message" "Cyan"
    Write-Host ("=" * 60) -ForegroundColor Cyan
}

function Build-ProjectZip {
    param([string]$RootDir)
    
    Write-Title "BUILDING PROJECT ZIP"
    
    if (-not $RootDir) {
        $RootDir = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    }
    
    Write-Host "Project root: $RootDir"
    
    try {
        $pythonVersion = python --version 2>&1
        Write-ColorOutput "Python: $pythonVersion" "Green"
    } catch {
        Write-ColorOutput "ERROR: Python not found. Please install Python 3.6+" "Red"
        exit 1
    }
    
    $distDir = Join-Path $RootDir "dist"
    if (-not (Test-Path $distDir)) {
        New-Item -ItemType Directory -Path $distDir -Force | Out-Null
        Write-Host "Created dist directory: $distDir"
    }
    
    $packageScript = Join-Path $RootDir "scripts\package_project.py"
    if (-not (Test-Path $packageScript)) {
        Write-ColorOutput "ERROR: package_project.py not found at: $packageScript" "Red"
        exit 1
    }
    
    Write-Host "Running package script..."
    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
    $archiveName = "awg-api-$timestamp"
    
    & python $packageScript --output-dir $distDir --archive-name $archiveName
    
    if ($LASTEXITCODE -ne 0) {
        Write-ColorOutput "ERROR: Failed to build ZIP archive" "Red"
        exit 1
    }
    
    $zipFiles = Get-ChildItem -Path $distDir -Filter "*.zip" -File | Sort-Object LastWriteTime -Descending
    
    if (-not $zipFiles) {
        Write-ColorOutput "ERROR: No ZIP file found in $distDir" "Red"
        exit 1
    }
    
    $zipPath = $zipFiles[0].FullName
    $zipSize = "{0:N2}" -f ($zipFiles[0].Length / 1MB) + " MB"
    
    Write-ColorOutput "[OK] ZIP created successfully" "Green"
    Write-Host "File: $(Split-Path $zipPath -Leaf)"
    Write-Host "Size: $zipSize"
    Write-Host ""
    
    return $zipPath
}

function Upload-ZipToServer {
    param(
        [string]$ZipPath,
        [string]$ServerIP,
        [string]$User,
        [int]$SSHPort,
        [string]$SSHKey
    )
    
    Write-Title "UPLOADING ZIP TO SERVER"
    
    $zipFileName = Split-Path $ZipPath -Leaf
    Write-Host "File: $zipFileName"
    Write-Host "To: $User@$ServerIP"
    Write-Host ""
    
    $scpArgs = @()
    
    if ($SSHKey) {
        $scpArgs += "-i"
        $scpArgs += $SSHKey
    }
    
    $scpArgs += "-P"
    $scpArgs += $SSHPort.ToString()
    $scpArgs += "-o"
    $scpArgs += "StrictHostKeyChecking=no"
    $scpArgs += "-o"
    $scpArgs += "UserKnownHostsFile=/dev/null"
    $scpArgs += $ZipPath
    $scpArgs += "$User@$ServerIP`:/tmp/$zipFileName"
    
    Write-ColorOutput "Uploading..." "Cyan"
    
    try {
        & scp @scpArgs
        
        if ($LASTEXITCODE -eq 0) {
            Write-ColorOutput "[OK] Upload successful" "Green"
            Write-Host ""
            return "/tmp/$zipFileName"
        } else {
            Write-ColorOutput "[ERROR] Upload failed with code: $LASTEXITCODE" "Red"
            exit 1
        }
    } catch {
        Write-ColorOutput "[ERROR] Error uploading file: $_" "Red"
        exit 1
    }
}

# Get server IP
if (-not $ServerIP) {
    Write-Title "SERVER CONNECTION"
    $ServerIP = Read-Host "Enter server IP address"
    
    if (-not $ServerIP) {
        Write-ColorOutput "ERROR: Server IP cannot be empty" "Red"
        exit 1
    }
}

Write-ColorOutput "[OK] Server IP: $ServerIP" "Green"
Write-Host ""

# Build project ZIP first
$zipPath = Build-ProjectZip -RootDir $ProjectRoot

# Get deployment mode
if (-not $Mode) {
    Write-Title "DEPLOYMENT MODE"
    Write-Host "Available modes:"
    Write-Host "  1. update           - Update existing installation"
    Write-Host "  2. clean-install    - Remove all data and reinstall from scratch"
    Write-Host ""
    
    $modeInput = Read-Host "Select mode (1 or 2)"
    
    switch ($modeInput.Trim()) {
        "1" { $Mode = "update" }
        "2" { $Mode = "clean-install" }
        "update" { $Mode = "update" }
        "clean-install" { $Mode = "clean-install" }
        default {
            Write-ColorOutput "ERROR: Invalid mode selected" "Red"
            exit 1
        }
    }
}

Write-ColorOutput "[OK] Mode: $Mode" "Green"
Write-Host ""

# Find SSH key
if (-not $SSHKey) {
    $keyPaths = @(
        "$env:USERPROFILE\.ssh\id_rsa",
        "$env:USERPROFILE\.ssh\id_ed25519",
        "$env:USERPROFILE\.ssh\amnezia_live"
    )
    
    foreach ($path in $keyPaths) {
        if (Test-Path $path) {
            $SSHKey = $path
            break
        }
    }
    
    if (-not $SSHKey) {
        Write-ColorOutput "WARNING: No SSH private key found in default locations" "Yellow"
        Write-Host "Default locations checked:"
        foreach ($path in $keyPaths) {
            Write-Host ("    - $path")
        }
        $keyInput = Read-Host "Enter SSH key path (or press Enter to skip)"
        
        if ($keyInput) {
            $SSHKey = $keyInput
        }
    }
}

if ($SSHKey -and -not (Test-Path $SSHKey)) {
    Write-ColorOutput "ERROR: SSH key not found at: $SSHKey" "Red"
    exit 1
}

if ($SSHKey) {
    Write-ColorOutput "[OK] SSH Key: $SSHKey" "Green"
}

Write-Host ""

# Confirmation
Write-Title "DEPLOYMENT CONFIGURATION"
Write-Host "Project ZIP:      $(Split-Path $zipPath -Leaf)"
Write-Host "Server IP:        $ServerIP"
Write-Host "SSH User:         $User"
Write-Host "SSH Port:         $SSHPort"
Write-Host "Deployment Mode:  $Mode"
if ($SSHKey) {
    Write-Host "SSH Key:          $SSHKey"
}
Write-Host ""

$confirm = Read-Host "Proceed with deployment (type yes)"
if ($confirm -ne "yes") {
    Write-ColorOutput "Deployment cancelled" "Yellow"
    exit 0
}

Write-Host ""
Write-Title "STARTING DEPLOYMENT"

# Upload ZIP to server
$remoteZipPath = Upload-ZipToServer -ZipPath $zipPath -ServerIP $ServerIP -User $User -SSHPort $SSHPort -SSHKey $SSHKey

# Build deployment command to execute on remote server
if ($Mode -eq "clean-install") {
    $remoteCmd = "rm -rf /opt/awg-api; mkdir -p /opt/awg-api; cd /opt/awg-api; unzip -q /tmp/*.zip; bash scripts/install_project.sh --mode clean-reinstall"
} else {
    $remoteCmd = "if [ ! -d /opt/awg-api ]; then mkdir -p /opt/awg-api; cd /opt/awg-api; unzip -q $remoteZipPath; else cd /opt/awg-api; unzip -o -q $remoteZipPath; fi; bash scripts/install_project.sh --mode update"
}

# Execute remote deployment
Write-ColorOutput "Executing deployment on server..." "Cyan"
Write-Host ""

try {
    $sshArgs = @()
    $sshArgs += "-p"
    $sshArgs += $SSHPort.ToString()
    
    if ($SSHKey) {
        $sshArgs += "-i"
        $sshArgs += $SSHKey
    }
    
    $sshArgs += "-o"
    $sshArgs += "StrictHostKeyChecking=no"
    $sshArgs += "-o"
    $sshArgs += "UserKnownHostsFile=/dev/null"
    $sshArgs += "$User@$ServerIP"
    $sshArgs += $remoteCmd
    
    & ssh @sshArgs
    
    if ($LASTEXITCODE -eq 0) {
        # Cleanup temporary zip file on server
        Write-ColorOutput "Cleaning up temporary files..." "Cyan"
        $cleanupCmd = "rm -f /tmp/*.zip"
        $cleanupArgs = @()
        $cleanupArgs += "-p"
        $cleanupArgs += $SSHPort.ToString()
        
        if ($SSHKey) {
            $cleanupArgs += "-i"
            $cleanupArgs += $SSHKey
        }
        
        $cleanupArgs += "-o"
        $cleanupArgs += "StrictHostKeyChecking=no"
        $cleanupArgs += "-o"
        $cleanupArgs += "UserKnownHostsFile=/dev/null"
        $cleanupArgs += "$User@$ServerIP"
        $cleanupArgs += $cleanupCmd
        
        & ssh @cleanupArgs 2>&1 | Out-Null
        
        Write-Host ""
        Write-Title "DEPLOYMENT SUCCESSFUL"
        Write-ColorOutput "[OK] Panel deployed successfully on $ServerIP" "Green"
        Write-Host ""
        Write-Host "Next steps:"
        Write-Host "  - Access the panel: http://$ServerIP`:8000"
        Write-Host "  - Check logs:       ssh -p $SSHPort $User@$ServerIP 'docker logs -f awg-api'"
        Write-Host ""
    } else {
        Write-Host ""
        Write-Title "DEPLOYMENT FAILED"
        Write-ColorOutput "[ERROR] Deployment exited with code: $LASTEXITCODE" "Red"
        Write-Host ""
        Write-Host "Troubleshooting:"
        if ($SSHKey) {
            Write-Host "  - Check SSH: ssh -p $SSHPort -i `"$SSHKey`" $User@$ServerIP whoami"
        } else {
            Write-Host "  - Check SSH: ssh -p $SSHPort $User@$ServerIP whoami"
        }
        Write-Host ""
        exit 1
    }
} catch {
    Write-Host ""
    Write-ColorOutput "[ERROR] Error executing deployment: $_" "Red"
    exit 1
}
#!/usr/bin/env pwsh
# Deploy-Panel.ps1 - Panel deployment script for Windows
# Builds project ZIP and deploys AWG API panel to remote server

param(
    [string]$ServerIP = "",
    [string]$Mode = "",
    [string]$SSHKey = "",
    [int]$SSHPort = 22,
    [string]$User = "root",
    [string]$ProjectRoot = ""
)

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "Cyan"
    )
    Write-Host $Message -ForegroundColor $Color
}

function Write-Title {
    param([string]$Message)
    Write-Host ""
    Write-Host ("=" * 60) -ForegroundColor Cyan
    Write-ColorOutput ">>> $Message" "Cyan"
    Write-Host ("=" * 60) -ForegroundColor Cyan
}

function Build-ProjectZip {
    param([string]$RootDir)
    
    Write-Title "BUILDING PROJECT ZIP"
    
    # Determine project root if not specified
    if (-not $RootDir) {
        $RootDir = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
    }
    
    Write-Host "Project root: $RootDir"
    
    # Check if Python is available
    try {
        $pythonVersion = python --version 2>&1
        Write-Host "Python: $pythonVersion" -ForegroundColor Green
    } catch {
        Write-ColorOutput "Fatal: Python not found. Please install Python 3.6+" "Red"
        exit 1
    }
    
    # Create dist directory
    $distDir = Join-Path $RootDir "dist"
    if (-not (Test-Path $distDir)) {
        New-Item -ItemType Directory -Path $distDir -Force | Out-Null
        Write-Host "Created dist directory: $distDir"
    }
    
    # Run package script
    $packageScript = Join-Path $RootDir "scripts\package_project.py"
    if (-not (Test-Path $packageScript)) {
        Write-ColorOutput "Fatal: package_project.py not found at: $packageScript" "Red"
        exit 1
    }
    
    Write-Host "Running package script..."
    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
    $archiveName = "awg-api-$timestamp"
    
    & python $packageScript --output-dir $distDir --archive-name $archiveName
    
    if ($LASTEXITCODE -ne 0) {
        Write-ColorOutput "Fatal: Failed to build ZIP archive" "Red"
        exit 1
    }
    
    # Find the created ZIP file
    $zipFiles = Get-ChildItem -Path $distDir -Filter "*.zip" -File | Sort-Object LastWriteTime -Descending
    
    if (-not $zipFiles) {
        Write-ColorOutput "Fatal: No ZIP file found in $distDir" "Red"
        exit 1
    }
    
    $zipPath = $zipFiles[0].FullName
    $zipSize = "{0:N2}" -f ($zipFiles[0].Length / 1MB) + " MB"
    
    Write-ColorOutput "[+] ZIP created successfully" "Green"
    Write-Host "File: $(Split-Path $zipPath -Leaf)"
    Write-Host "Size: $zipSize"
    Write-Host ""
    
    return $zipPath
}

function Upload-ZipToServer {
    param(
        [string]$ZipPath,
        [string]$ServerIP,
        [string]$User,
        [int]$SSHPort,
        [string]$SSHKey
    )
    
    Write-Title "UPLOADING ZIP TO SERVER"
    
    $zipFileName = Split-Path $ZipPath -Leaf
    Write-Host "File: $zipFileName"
    Write-Host "To: $User@$ServerIP"
    Write-Host ""
    
    # Build SCP command
    $scpArgs = @()
    
    if ($SSHKey) {
        $scpArgs += "-i"
        $scpArgs += $SSHKey
    }
    
    $scpArgs += "-P"
    $scpArgs += $SSHPort.ToString()
    $scpArgs += "-o"
    $scpArgs += "StrictHostKeyChecking=no"
    $scpArgs += "-o"
    $scpArgs += "UserKnownHostsFile=/dev/null"
    $scpArgs += $ZipPath
    $scpArgs += "$User@$ServerIP`:/tmp/$zipFileName"
    
    Write-ColorOutput "Uploading..." "Cyan"
    
    try {
        & scp @scpArgs
        
        if ($LASTEXITCODE -eq 0) {
            Write-ColorOutput "[+] Upload successful" "Green"
            Write-Host ""
            return "/tmp/$zipFileName"
        } else {
            Write-ColorOutput "[!] Upload failed with code: $LASTEXITCODE" "Red"
            exit 1
        }
    } catch {
        Write-ColorOutput "[!] Error uploading file: $_" "Red"
        exit 1
    }
}

# Get server IP
if (-not $ServerIP) {
    Write-Title "SERVER CONNECTION"
    $ServerIP = Read-Host "Enter server IP address"
    
    if (-not $ServerIP) {
        Write-ColorOutput "Error: Server IP cannot be empty" "Red"
        exit 1
    }
}

Write-ColorOutput "[+] Server IP: $ServerIP" "Green"
Write-Host ""

# Build project ZIP first
$zipPath = Build-ProjectZip -RootDir $ProjectRoot

# Get deployment mode
if (-not $Mode) {
    Write-Title "DEPLOYMENT MODE"
    Write-Host "Available modes:"
    Write-Host "  1. update           - Update existing installation"
    Write-Host "  2. clean-install    - Remove all data and reinstall from scratch"
    Write-Host ""
    
    $modeInput = Read-Host "Select mode (1 or 2)"
    
    switch ($modeInput.Trim()) {
        "1" { $Mode = "update" }
        "2" { $Mode = "clean-install" }
        "update" { $Mode = "update" }
        "clean-install" { $Mode = "clean-install" }
        default {
            Write-ColorOutput "Error: Invalid mode selected" "Red"
            exit 1
        }
    }
}

Write-ColorOutput "[+] Mode: $Mode" "Green"
Write-Host ""

# Find SSH key
if (-not $SSHKey) {
    $keyPaths = @(
        "$env:USERPROFILE\.ssh\id_rsa",
        "$env:USERPROFILE\.ssh\id_ed25519",
        "$env:USERPROFILE\.ssh\amnezia_live"
    )
    
    foreach ($path in $keyPaths) {
        if (Test-Path $path) {
            $SSHKey = $path
            break
        }
    }
    
    if (-not $SSHKey) {
        Write-ColorOutput "WARNING: No SSH private key found in default locations" "Yellow"
        Write-Host "Default locations checked:"
        foreach ($path in $keyPaths) {
            Write-Host ("    - $path")
        }
        $keyInput = Read-Host "Enter SSH key path (or press Enter to skip)"
        
        if ($keyInput) {
            $SSHKey = $keyInput
        }
    }
}

if ($SSHKey -and -not (Test-Path $SSHKey)) {
    Write-ColorOutput "Error: SSH key not found at: $SSHKey" "Red"
    exit 1
}

if ($SSHKey) {
    Write-ColorOutput "[+] SSH Key: $SSHKey" "Green"
}

Write-Host ""

# Confirmation
Write-Title "DEPLOYMENT CONFIGURATION"
Write-Host "Project ZIP:      $(Split-Path $zipPath -Leaf)"
Write-Host "Server IP:        $ServerIP"
Write-Host "SSH User:         $User"
Write-Host "SSH Port:         $SSHPort"
Write-Host "Deployment Mode:  $Mode"
if ($SSHKey) {
    Write-Host "SSH Key:          $SSHKey"
}
Write-Host ""

$confirm = Read-Host "Proceed with deployment? (type 'yes')"
if ($confirm -ne "yes") {
    Write-ColorOutput "Deployment cancelled" "Yellow"
    exit 0
}

Write-Host ""
Write-Title "STARTING DEPLOYMENT"

# Upload ZIP to server
$remoteZipPath = Upload-ZipToServer -ZipPath $zipPath -ServerIP $ServerIP -User $User -SSHPort $SSHPort -SSHKey $SSHKey

# Build deployment command to execute on remote server
if ($Mode -eq "clean-install") {
    $remoteCmd = @"
rm -rf /opt/awg-api
mkdir -p /opt/awg-api
cd /opt/awg-api
unzip -q /tmp/*.zip
bash scripts/install_project.sh --mode clean-reinstall
"@
} else {
    $remoteCmd = @"
if [ ! -d /opt/awg-api ]; then
    mkdir -p /opt/awg-api
    cd /opt/awg-api
    unzip -q $remoteZipPath
else
    cd /opt/awg-api
    unzip -o -q $remoteZipPath
fi
bash scripts/install_project.sh --mode update
"@
}

# Execute remote deployment
Write-ColorOutput "Connecting to $ServerIP and executing deployment..." "Cyan"
Write-Host ""

try {
    $sshArgs = @()
    $sshArgs += "-p"
    $sshArgs += $SSHPort.ToString()
    
    if ($SSHKey) {
        $sshArgs += "-i"
        $sshArgs += $SSHKey
    }
    
    $sshArgs += "-o"
    $sshArgs += "StrictHostKeyChecking=no"
    $sshArgs += "-o"
    $sshArgs += "UserKnownHostsFile=/dev/null"
    $sshArgs += "$User@$ServerIP"
    $sshArgs += $remoteCmd
    
    & ssh @sshArgs
    
    if ($LASTEXITCODE -eq 0) {
        # Cleanup temporary zip file on server
        Write-ColorOutput "Cleaning up temporary files..." "Cyan"
        $cleanupCmd = "rm -f /tmp/*.zip"
        $cleanupArgs = @()
        $cleanupArgs += "-p"
        $cleanupArgs += $SSHPort.ToString()
        
        if ($SSHKey) {
            $cleanupArgs += "-i"
            $cleanupArgs += $SSHKey
        }
        
        $cleanupArgs += "-o"
        $cleanupArgs += "StrictHostKeyChecking=no"
        $cleanupArgs += "-o"
        $cleanupArgs += "UserKnownHostsFile=/dev/null"
        $cleanupArgs += "$User@$ServerIP"
        $cleanupArgs += $cleanupCmd
        
        & ssh @cleanupArgs 2>&1 | Out-Null
        
        Write-Host ""
        Write-Title "DEPLOYMENT SUCCESSFUL"
        Write-ColorOutput "[+] Panel deployed successfully on $ServerIP" "Green"
        Write-Host ""
        Write-Host "Next steps:"
        Write-Host "  - Access the panel: http://$ServerIP`:8000"
        Write-Host "  - Check logs:       ssh -p $SSHPort $User@$ServerIP 'docker logs -f awg-api'"
        Write-Host ""
    } else {
        Write-Host ""
        Write-Title "DEPLOYMENT FAILED"
        Write-ColorOutput "[!] Deployment exited with code: $LASTEXITCODE" "Red"
        Write-Host ""
        Write-Host "Troubleshooting:"
        if ($SSHKey) {
            Write-Host "  - Check SSH: ssh -p $SSHPort -i `"$SSHKey`" $User@$ServerIP whoami"
        } else {
            Write-Host "  - Check SSH: ssh -p $SSHPort $User@$ServerIP whoami"
        }
        Write-Host ""
        exit 1
    }
} catch {
    Write-Host ""
    Write-ColorOutput "[!] Error executing deployment: $_" "Red"
    exit 1
}
#!/usr/bin/env pwsh
# Deploy-Panel.ps1 - Panel deployment script for Windows
# Deploys AWG API panel to remote server with mode selection

param(
    [string]$ServerIP = "",
    [string]$Mode = "",
    [string]$SSHKey = "",
    [int]$SSHPort = 22,
    [string]$User = "root"
)

# Color codes for output
function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "Cyan"
    )
    
    $colorMap = @{
        "Green"  = "Green"
        "Red"    = "Red"
        "Yellow" = "Yellow"
        "Cyan"   = "Cyan"
    }
    
    Write-Host $Message -ForegroundColor $colorMap[$Color]
}

function Write-Title {
    param([string]$Message)
    
    Write-Host ""
    Write-Host ("=" * 60) -ForegroundColor Cyan
    Write-ColorOutput ">>> $Message" "Cyan"
    Write-Host ("=" * 60) -ForegroundColor Cyan
}

# Get server IP
if (-not $ServerIP) {
    Write-Title "SERVER CONNECTION"
    $ServerIP = Read-Host "Enter server IP address"
    
    if (-not $ServerIP) {
        Write-ColorOutput "Error: Server IP cannot be empty" "Red"
        exit 1
    }
}

Write-ColorOutput ("✓ Server IP: $ServerIP") "Green"
Write-Host ""

# Get deployment mode
if (-not $Mode) {
    Write-Title "DEPLOYMENT MODE"
    Write-Host "Available modes:"
    Write-Host "  1. update           - Update existing installation"
    Write-Host "  2. clean-install    - Remove all data and reinstall from scratch"
    Write-Host ""
    
    $modeInput = Read-Host "Select mode (1 or 2, or type update/clean-install)"
    
    switch ($modeInput.ToLower()) {
        "1" { $Mode = "update" }
        "2" { $Mode = "clean-install" }
        "update" { $Mode = "update" }
        "clean-install" { $Mode = "clean-install" }
        default {
            Write-ColorOutput "Error: Invalid mode selected" "Red"
            exit 1
        }
    }
}

Write-ColorOutput ("✓ Mode: $Mode") "Green"
Write-Host ""

# Find SSH key
if (-not $SSHKey) {
    $keyPaths = @(
        "$env:USERPROFILE\.ssh\id_rsa",
        "$env:USERPROFILE\.ssh\id_ed25519",
        "$env:USERPROFILE\.ssh\amnezia_live"
    )
    
    foreach ($path in $keyPaths) {
        if (Test-Path $path) {
            $SSHKey = $path
            break
        }
    }
    
    if (-not $SSHKey) {
        Write-ColorOutput "WARNING: No SSH private key found in default locations" "Yellow"
        Write-Host "Default locations checked:"
        foreach ($path in $keyPaths) {
            Write-Host ("    - $path")
        }
        $keyInput = Read-Host "Enter SSH key path (or press Enter to skip)"
        
        if ($keyInput) {
            $SSHKey = $keyInput
        }
    }
}

if ($SSHKey -and -not (Test-Path $SSHKey)) {
    Write-ColorOutput "Error: SSH key not found at: $SSHKey" "Red"
    exit 1
}

if ($SSHKey) {
    Write-ColorOutput ("✓ SSH Key: $SSHKey") "Green"
}

Write-Host ""

# Confirmation
Write-Title "DEPLOYMENT CONFIGURATION"
Write-Host "Server IP:        $ServerIP"
Write-Host "SSH User:         $User"
Write-Host "SSH Port:         $SSHPort"
Write-Host "Deployment Mode:  $Mode"
if ($SSHKey) {
    Write-Host "SSH Key:          $SSHKey"
}
Write-Host ""

$confirm = Read-Host "Proceed with deployment? (yes/no)"
if ($confirm -ne "yes") {
    Write-ColorOutput "Deployment cancelled" "Yellow"
    exit 0
}

Write-Host ""
Write-Title "STARTING DEPLOYMENT"

# Build deployment command to execute on remote server
if ($Mode -eq "clean-install") {
    $remoteCmd = @"
if [ ! -d /opt/awg-api ]; then
    echo "(!) /opt/awg-api directory not found. Creating..."
    mkdir -p /opt/awg-api
fi

cd /opt/awg-api && bash scripts/install_project.sh --mode clean-reinstall
"@
} else {
    $remoteCmd = @"
if [ ! -d /opt/awg-api ]; then
    echo "ERROR: /opt/awg-api directory not found"
    echo "Run with mode 'clean-install' for fresh installation"
    exit 1
fi

cd /opt/awg-api && bash scripts/install_project.sh --mode update
"@
}

# Execute remote deployment
Write-ColorOutput "Connecting to $ServerIP and executing deployment..." "Cyan"
Write-Host ""

try {
    $sshArgs = @()
    $sshArgs += "-p"
    $sshArgs += $SSHPort.ToString()
    
    if ($SSHKey) {
        $sshArgs += "-i"
        $sshArgs += $SSHKey
    }
    
    $sshArgs += "-o"
    $sshArgs += "StrictHostKeyChecking=no"
    $sshArgs += "-o"
    $sshArgs += "UserKnownHostsFile=/dev/null"
    $sshArgs += "$User@$ServerIP"
    $sshArgs += $remoteCmd
    
    & ssh @sshArgs
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Title "DEPLOYMENT SUCCESSFUL"
        Write-ColorOutput ("✓ Panel deployed successfully on $ServerIP") "Green"
        Write-Host ""
        Write-Host "Next steps:"
        Write-Host ("  - Access the panel: http://$ServerIP" + ":8000")
        Write-Host ("  - Check logs:       ssh -p $SSHPort $User@$ServerIP 'docker logs -f awg-api'")
        Write-Host ""
    } else {
        Write-Host ""
        Write-Title "DEPLOYMENT FAILED"
        Write-ColorOutput ("Deployment exited with code: $LASTEXITCODE") "Red"
        Write-Host ""
        Write-Host "Troubleshooting:"
        Write-Host ("  - Check SSH connection: ssh -p $SSHPort -i `"$SSHKey`" $User@$ServerIP whoami")
        Write-Host ("  - Check project exists: ssh -p $SSHPort -i `"$SSHKey`" $User@$ServerIP 'ls -la /opt/awg-api'")
        Write-Host ("  - View logs: ssh -p $SSHPort -i `"$SSHKey`" $User@$ServerIP 'docker logs awg-api'")
        Write-Host ""
        exit 1
    }
} catch {
    Write-Host ""
    Write-ColorOutput ("Error executing deployment: $_") "Red"
    exit 1
}
