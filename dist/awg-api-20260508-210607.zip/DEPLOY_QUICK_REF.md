# Deploy-Panel - Краткая справка

## 🚀 Быстрый старт

```bash
# Интерактивный режим (рекомендуется)
# Автоматически собирает ZIP и развертывает на сервер
.\Deploy-Panel.ps1

# или из Command Prompt
Deploy-Panel.bat
```

## 📋 Процесс развертывания

1. **Сборка ZIP** - автоматическая сборка проекта в архив
2. **Загрузка** - передача ZIP на сервер через SCP
3. **Развертывание** - распаковка и запуск install скрипта
4. **Очистка** - удаление временных файлов на сервере

## 📋 Примеры команд

### Базовые варианты
```powershell
# Обновление (интерактивно)
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "update"

# Чистая установка
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "clean-install"

# Со специальным SSH ключом
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "update" `
    -SSHKey "C:\Users\Admin\.ssh\id_rsa"

# На нестандартном порту
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "update" -SSHPort 2222

# От другого пользователя
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "update" -User "deploy"
```

### Из Command Prompt
```batch
Deploy-Panel.bat 192.168.1.100 update

Deploy-Panel.bat 192.168.1.100 clean-install "C:\Users\Admin\.ssh\id_rsa"
```

## 🔧 Режимы

| Режим | Описание | Данные | Когда использовать |
|-------|---------|--------|-------------------|
| `update` | Обновить существующую установку | ✓ Сохраняет | Обновление кода |
| `clean-install` | Полная переустановка | ✗ Удаляет | Первая установка |

## ⚠️ Важно

- **clean-install удаляет все данные!** Сделайте backup перед этим.
- SSH ключ нужен для подключения к серверу
- Требуется сетевой доступ до сервера на порт 22 (или указанный)

## 🔗 Полная документация

Смотрите [DEPLOY_GUIDE.md](DEPLOY_GUIDE.md) для подробной информации.

## ❓ Частые проблемы

```powershell
# Ошибка "ssh: command not found" → Установите SSH
# Ошибка "Permission denied" → Проверьте SSH ключ и доступ
# Ошибка "Connection refused" → Проверьте IP и доступность сервера

# Проверить доступ к серверу:
Test-NetConnection -ComputerName "192.168.1.100" -Port 22

# Проверить SSH ключ:
ssh -v -i "C:\Users\Admin\.ssh\id_rsa" root@192.168.1.100 whoami

# Просмотр логов на сервере:
ssh root@192.168.1.100 "docker logs -f awg-api"
```

## 💾 Первый запуск

1. Убедитесь, что проект AWG API находится в `/opt/awg-api` на сервере
2. Если проекта нет, используйте режим `clean-install`
3. После успешного запуска проверьте доступ:
   - Панель: `http://192.168.1.100:8000`
   - Логи: `ssh root@192.168.1.100 "docker logs awg-api"`

## 📞 Поддержка

Смотрите секцию "Решение проблем" в [DEPLOY_GUIDE.md](DEPLOY_GUIDE.md#решение-проблем)
