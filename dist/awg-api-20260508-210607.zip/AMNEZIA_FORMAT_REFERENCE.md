# Справочник форматов Amnezia конфигов

## JSON Структура vpn:// ссылки (правильный формат)

```json
{
  "containers": [
    {
      "container": "amnezia-awg",  // v1 legacy или "amnezia-awg2" для v2
      "awg": {
        // Обязательные параметры
        "port": "51820",
        "transport_proto": "udp",
        
        // Параметры обфускации (все должны присутствовать!)
        "Jc": "4",              // Количество junk пакетов
        "Jmin": "50",           // Минимальный размер junk пакета
        "Jmax": "100",          // Максимальный размер junk пакета
        "S1": "87",             // Padding для handshake init
        "S2": "65",             // Padding для handshake response
        "S3": "20",             // Padding для handshake cookie
        "S4": "25",             // Padding для transport сообщений
        
        // Header значения (могут быть пусто если не использованы)
        "H1": "1000000000",     // Header для handshake init (число, не диапазон!)
        "H2": "2000000000",     // Header для handshake response
        "H3": "3000000000",     // Header для handshake cookie
        "H4": "4000000000",     // Header для transport
        
        // Конфиг в текстовом формате (для отображения)
        "last_config": "[Interface]\n[Peer]\n..."
      }
    }
  ],
  "defaultContainer": "amnezia-awg",
  "description": "User Name",
  "dns1": "1.1.1.1",
  "dns2": "1.0.0.1",
  "hostName": "vpn.example.com",
  "nameOverriddenByUser": true
}
```

---

## WireGuard конфиг формат (текстовый, в last_config)

### Правильный минимальный конфиг:
```ini
[Interface]
Address = 10.0.0.2/32
DNS = $PRIMARY_DNS, $SECONDARY_DNS
PrivateKey = <base64 encoded private key>
Jc = 4
Jmin = 50
Jmax = 100
S1 = 87
S2 = 65
S3 = 20
S4 = 25
H1 = 1000000000
H2 = 2000000000
H3 = 3000000000
H4 = 4000000000
I1 = <r 2><b 0x858000010001>

[Peer]
PublicKey = <server public key>
PresharedKey = <preshared key>
AllowedIPs = 0.0.0.0/0, ::/0
Endpoint = vpn.example.com:51820
PersistentKeepalive = 25
```

### Важные правила:
1. **Нулевые параметры НЕ добавлять** в конфиг файл (они по умолчанию 0)
   - ❌ `Jc = 0` - не писать
   - ✅ Просто опустить, если значение 0

2. **Пустые I1-I5 НЕ добавлять** в конфиг файл
   - ❌ `I1 =` - пусто, не писать
   - ✅ Опустить, если значение пусто

3. **H значения ВСЕГДА целые числа**, не диапазоны
   - ❌ `H1 = 1000000000-1000000010` - неправильно
   - ✅ `H1 = 1000000000` - правильно (уже выбранное значение)

4. **S1-S4 ВСЕГДА должны быть в JSON ** даже если 0
   - ❌ Отсутствие S3/S4 в protocol_payload - ошибка
   - ✅ `"S3": "0"` - всегда присутствует

---

## Теги для I1-I5 (Custom Signature Packets)

От `amneziawg-go` README:

### Теги для конфига:
- `<b 0x[hex]>` - Static bytes (static bytes tag)
  - Примеры: `<b 0x858000>`, `<b 0xDEADBEEF>`
  - Hex строка без пробелов, чётное количество символов

- `<r [size]>` - Random bytes (random bytes tag)
  - Примеры: `<r 2>`, `<r 32>`

- `<rd [size]>` - Random digits (0-9)
  - Примеры: `<rd 4>`
  
- `<rc [size]>` - Random chars (a-zA-Z)
  - Примеры: `<rc 8>`
  
- `<t>` - Timestamp (4-byte UNIX)

### Пример полного I1:
```
I1 = <r 2><b 0x858000010001000000000669636c6f756403636f6d0000010001c00c000100010000105a00044d583737>
```

---

## Рекомендуемые значения параметров

Из `amneziawg-linux-kernel-module` README:

### Для MTU=1280 (стандартный интернет):
| Параметр | Min | Rec Min | Rec Max | Max | Примечания |
|----------|-----|---------|---------|-----|-----------|
| **Jc** | 1 | 4 | 12 | 128 | Count junk packets |
| **Jmin** | 1 | 8 | 8 | 1280 | Min junk size |
| **Jmax** | Jmin | 80 | 80 | 1280 | Max junk size |
| **S1** | 0 | 15 | 150 | 1132 | Handshake init padding |
| **S2** | 0 | 15 | 150 | 1188 | Handshake response padding |
| **S3** | 0 | 0 | 50 | ? | Handshake cookie padding |
| **S4** | 0 | 0 | 50 | ? | Transport padding |
| **H1-H4** | 5 | 1000000000 | 2147483647 | 2^31-1 | Must be unique |

### Правило для Jmin/Jmax:
- `Jmin < Jmax`
- Рекомендуемый диапазон: Jmin=8, Jmax=80

### Правило для S параметров:
- `S1 ≤ 1132` (1280 - 148)
- `S2 ≤ 1188` (1280 - 92)
- `S1 + 56 ≠ S2` (исключить совпадающие размеры после обработки)

### Правило для H параметров:
- H1, H2, H3, H4 должны быть **уникальны** между собой
- Могут быть записаны как:
  - Одно число: `1234567`
  - Диапазон (при генерации сервером): `123456-789012`

---

## Важные различия V1 vs V2

### V1 (Legacy amnezia-awg)
- Использует старую версию WireGuard с Amnezia модификациями
- Контейнер: `amnezia-awg`
- Бинари: `wg` (wireguard-tools)
- Конфиг: `wg0.conf` (если используется на Linux kernel module)

### V2 (New amnezia-awg2)
- Использует Go реализацию с полной Amnezia поддержкой
- Контейнер: `amnezia-awg2`
- Бинари: `awg` (amneziawg-tools)
- Конфиг: `awg0.conf`

**Оба режима должны генерировать конфиги одинаково**, за исключением названия контейнера.

---

## Правила обработки в коде

### При построении client_payload:
```python
# ВСЕГДА добавляй все параметры
client_payload = {
    "Jc": str(iface.get("Jc", "0")),    # Значение или 0
    "Jmin": str(iface.get("Jmin", "0")),
    "Jmax": str(iface.get("Jmax", "0")),
    "S1": str(iface.get("S1", "0")),    # ВАЖНО: значение по умолч. = 0
    "S2": str(iface.get("S2", "0")),
    "S3": str(iface.get("S3", "0")),    # ✅ ДОБАВЛЕНЫ ВСЕГДА
    "S4": str(iface.get("S4", "0")),    # ✅ ДОБАВЛЕНЫ ВСЕГДА
    "H1": sampled_h.get("H1", ""),      # Из _pick_h() или пусто
    "H2": sampled_h.get("H2", ""),
    "H3": sampled_h.get("H3", ""),
    "H4": sampled_h.get("H4", ""),
    "I1": special_junk.get("I1", ""),   # Или пусто
    "I2": special_junk.get("I2", ""),
    # ...
}
```

### При построении protocol_payload:
```python
# ВСЕГДА включай S3 и S4
protocol_payload = {
    "Jc": client_payload["Jc"],
    "Jmin": client_payload["Jmin"],
    "Jmax": client_payload["Jmax"],
    "S1": client_payload["S1"],
    "S2": client_payload["S2"],
    "S3": client_payload["S3"],     # ✅ ВСЕГДА ЗДЕСЬ
    "S4": client_payload["S4"],     # ✅ ВСЕГДА ЗДЕСЬ
    "H1": client_payload.get("H1", ""),
    "H2": client_payload.get("H2", ""),
    "H3": client_payload.get("H3", ""),
    "H4": client_payload.get("H4", ""),
    "port": str(iface["ListenPort"]),
    "transport_proto": "udp",
    "last_config": raw_config_string,
}
```

### При построении raw_lines (текстовый конфиг):
```python
# ТОЛЬКО добавляй если значение не 0
for key in ("Jc", "Jmin", "Jmax", "S1", "S2", "S3", "S4"):
    value = client_payload.get(key)
    if value and value != "0":      # ✅ Проверка на 0
        raw_lines.append(f"{key} = {value}")

# ТОЛЬКО добавляй H если есть значение
for key in ("H1", "H2", "H3", "H4"):
    value = client_payload.get(key)
    if value:
        raw_lines.append(f"{key} = {value}")

# ТОЛЬКО добавляй I если есть значение
for key in ("I1", "I2", "I3", "I4", "I5"):
    value = client_payload.get(key, "")
    if value:                       # ✅ Пропусти пусто
        raw_lines.append(f"{key} = {value}")
```

---

## Источники

- [amneziawg-go - Configuration](https://github.com/amnezia-vpn/amneziawg-go#configuration)
- [amneziawg-linux-kernel-module - Configuration](https://github.com/amnezia-vpn/amneziawg-linux-kernel-module#configuration)
- [WireGuard Manual](https://man.archlinux.org/man/wg.8)
