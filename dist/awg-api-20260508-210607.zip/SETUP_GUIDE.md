# AWG API Setup Guide

Комплексный скрипт для установки AWG API Master (панель управления) и Node (удаленные узлы).

## Быстрый старт

```bash
chmod +x setup.sh
./setup.sh
```

## Упаковка в ZIP и установка на сервер

Если нужен поток "одним нажатием упаковать -> передать -> распаковать и установить", используйте единый entrypoint `setup.sh`.

Примечание: скрипты в `scripts/` являются внутренними. Публичный интерфейс для установки — только `setup.sh`.

### 1. Упаковать проект (Windows)

```powershell
python scripts/package_project.py
```

Архив будет создан в каталоге `dist/`.

### 2. Передать архив и install-скрипт на сервер

```bash
scp dist/awg-api-*.zip root@<SERVER_IP>:/tmp/
scp scripts/install_from_zip.sh root@<SERVER_IP>:/tmp/
```

### 3. На сервере распаковать и запустить

```bash
ssh root@<SERVER_IP>
cd /opt/awg-api
bash ./setup.sh from-zip --zip /tmp/awg-api-20260413-143001.zip
```

Режимы установки:

```bash
# Безопасное обновление панели (по умолчанию): сохраняет .env и state/
bash ./setup.sh from-zip --zip /tmp/awg-api-20260413-143001.zip --mode update

# Чистая переустановка: удаляет state/ и runtime env
bash ./setup.sh from-zip --zip /tmp/awg-api-20260413-143001.zip --mode clean-reinstall
```

Дополнительно:

```bash
# установить в другой каталог
bash /tmp/install_from_zip.sh --zip /tmp/awg-api.zip --target-dir /srv/awg-api

# только распаковать, без docker compose up -d --build
bash /tmp/install_from_zip.sh --zip /tmp/awg-api.zip --skip-build

# Явно выбрать режим
bash /tmp/install_from_zip.sh --zip /tmp/awg-api.zip --mode update
bash /tmp/install_from_zip.sh --zip /tmp/awg-api.zip --mode clean-reinstall
```

## Режимы установки

### 1. **Master (Панель управления) - Локальная установка**

Устанавливает веб-панель управления на локальном компьютере.

**Что устанавливается:**
- REST API на порту 8000
- gRPC control plane на порту 50051
- Веб-интерфейс управления
- Локальный PKI (сертификаты)

**Требования:**
- Docker
- Docker Compose
- IP адрес для фильтрации доступа

**Процесс:**
1. Запустите скрипт: `./setup.sh`
2. Выберите `1) Install Master (Web Panel) - Local`
3. Введите IP адрес, с которого разрешен доступ к API (или `0.0.0.0` для любого)
4. Введите публичный IP адрес панели (для конфигов клиентов)
5. Введите DNS для клиентов (по умолчанию `1.1.1.1`)

**После установки:**
- Откройте http://127.0.0.1:8000 в браузере
- API key будет выведен в терминале - сохраните его
- Готово добавлять узлы (nodes)

**Пример:**
```
Allowed caller IPv4: 192.168.1.100
Public IP for clients: 5.101.82.46
DNS for clients: 1.1.1.1
```

---

### 2. **Node (Узел) - Локальная установка**

Устанавливает управляемый узел на локальном компьютере, подчиняющийся Master.

**Что устанавливается:**
- REST API на порту 8000 (bootstrap)
- gRPC управляемый режим
- Подключение к Master для управления

**Требования:**
- Docker
- Docker Compose
- IP адрес Master
- Работающий AmneziaWG контейнер

**Процесс:**
1. Сначала установите Master
2. Запустите скрипт: `./setup.sh`
3. Выберите `2) Install Node - Local`
4. Введите IP адрес Master
5. Введите порт API Master (обычно `8000`)
6. Введите IP для фильтрации доступа

**После установки:**
- Перейдите в панель Master
- Добавьте узел: IP = `<ваш IP>`, Port = `8000`
- Нажмите "Connect node API"
- Узел автоматически зарегистрируется

**Пример:**
```
Master IP address: 192.168.1.10
Master API port: 8000
Allowed caller IPv4: 192.168.1.10
```

---

### 3. **Node (Узел) - Удаленная установка (SSH)**

Устанавливает управляемый узел на удаленном сервере через SSH.

**Что устанавливается:**
- Полная копия проекта на удаленном сервере
- Docker контейнеры
- Автоматическая регистрация в Master

**Требования:**
- SSH доступ к удаленному серверу
- SSH приватный ключ
- SSH user (обычно `root`)
- Docker на удаленном сервере
- Работающий AmneziaWG контейнер на удаленном сервере

**Процесс:**
1. Убедитесь, что SSH ключ присутствует: `.ssh-live/amnezia_live`
2. Запустите скрипт: `./setup.sh`
3. Выберите `3) Install Node - Remote (via SSH)`
4. Введите IP или hostname удаленного сервера
5. Введите SSH user (обычно `root`)
6. Введите SSH порт (обычно `22`)
7. Введите путь к SSH приватному ключу
8. Введите параметры подключения к Master

**После установки:**
- Скрипт выведет команды для просмотра логов
- Узел готов к регистрации в Master
- Можно проверить здоровье: `curl http://<удаленный IP>:8000/health`

**Пример:**
```
Remote SSH server IP or hostname: 192.168.1.50
SSH user: root
SSH port: 22
SSH private key path: .ssh-live/amnezia_live
Master IP address: 192.168.1.10
Node public IP for clients: 192.168.1.50
```

---

## Дополнительные команды

### Статус сервисов
```bash
./setup.sh  # Выберите пункт 4
# или
docker-compose ps
```

### Просмотр логов
```bash
./setup.sh  # Выберите пункт 5
# или
docker-compose logs -f
```

### Остановка сервисов
```bash
./setup.sh  # Выберите пункт 6
# или
docker-compose down
```

### Перезагрузка сервисов
```bash
docker-compose restart
```

---

## Переменные окружения (.env)

После каждой установки создается файл `.env` с конфигурацией:

| Переменная | Описание | Пример |
|-----------|---------|--------|
| `AWG_ROLE` | master или node | `master` |
| `AWG_API_KEY` | API ключ для доступа | `base64-encoded-key` |
| `AWG_SERVER_HOST` | Публичный IP для клиентов | `5.101.82.46` |
| `AWG_ALLOWED_IPS` | IP адреса с доступом к API | `192.168.1.100` |
| `AWG_MASTER_IP` | IP Master (для node) | `192.168.1.10` |
| `AWG_GRPC_PORT` | Порт gRPC | `50051` |
| `AWG_DNS` | DNS для клиентов VPN | `1.1.1.1` |

---

## Архитектура Master/Node

```
Master (Панель управления)
├── REST API на :8000
├── gRPC на :50051
├── PKI (сертификаты + CA)
└── Веб-интерфейс

    ↓ (控制plane через gRPC+mTLS)

Node #1 (удаленный)
├── REST API на :8000 (bootstrap)
├── gRPC managed режим
└── AmneziaWG контейнер

Node #2 (удаленный)
├── REST API на :8000 (bootstrap)
├── gRPC managed режим
└── AmneziaWG контейнер
```

### Процесс регистрации Node:
1. **Bootstrap** - Node готов к первичному подключению
2. **Connection** - Master подключается к Node (IP + port)
3. **Enrollment** - Master подписывает сертификат Node
4. **Managed** - Node переходит в режим управления (gRPC+mTLS)
5. **Locked** - Node привязан к одному Master

---

## Быстрые команды для SSH

```bash
# Статус контейнеров на удаленном сервере
ssh -p 22 root@192.168.1.50 "cd /opt/awg-api && docker-compose ps"

# Логи контейнера
ssh -p 22 root@192.168.1.50 "cd /opt/awg-api && docker-compose logs -f awg-api"

# Проверка здоровья API
ssh -p 22 root@192.168.1.50 "curl http://127.0.0.1:8000/health"

# Перезагрузка контейнеров
ssh -p 22 root@192.168.1.50 "cd /opt/awg-api && docker-compose restart"
```

---

## Решение проблем

### API контейнер не стартует
```bash
docker-compose logs awg-api
# Проверьте переменные в .env файле
```

### Нет доступа к API
```bash
# Проверьте дозволенные IP в .env
# Обновите AWG_ALLOWED_IPS если необходимо
docker-compose down
docker-compose up -d
```

### Node не подключается к Master
```bash
# Проверьте IP Master в .env
# Убедитесь, что firewall не блокирует порты 8000 и 50051
# Проверьте логи: docker-compose logs awg-api
```

### SSH ключ не работает
```bash
# Убедитесь, что ключ имеет правильные права
chmod 600 .ssh-live/amnezia_live

# Проверьте подключение вручную
ssh -i .ssh-live/amnezia_live root@192.168.1.50 "echo OK"
```

---

## Автоматизация (Ansible/Terraform)

Для массовой установки можно использовать:

```bash
# Скопируйте конфиги через ansible
ansible all -m copy -a "src=setup.sh dest=/tmp/"

# Или запустите скрипт параметрами (если расширить функциональность)
./setup.sh --role node --master 192.168.1.10 --client-ip 192.168.1.100
```

---

## Log файл

Все операции логируются в `/var/log/awg-api-setup.log`

```bash
tail -f /var/log/awg-api-setup.log
```
