# Deployment Guide - Windows to Server

Скрипты для развертывания панели AWG API на удаленный сервер с Windows машины.

## Содержание

- [Требования](#требования)
- [Быстрый старт](#быстрый-старт)
- [Варианты использования](#варианты-использования)
- [Режимы развертывания](#режимы-развертывания)
- [Параметры скрипта](#параметры-скрипта)
- [Решение проблем](#решение-проблем)

## Требования

### На Windows:
- PowerShell 5.0 или выше
- SSH клиент (встроен в Windows 10+ или установлен через Git Bash / PuTTY)
- Доступ в интернет до сервера

### На сервере:
- Linux (Ubuntu, Debian, CentOS)
- Docker и Docker Compose
- SSH сервер с открытым портом
- Проект AWG API в `/opt/awg-api`

### SSH ключ:
- Private SSH key для подключения к серверу
- По умолчанию скрипт ищет ключи в:
  - `~/.ssh/id_rsa`
  - `~/.ssh/id_ed25519`
  - `~/.ssh/amnezia_live`

## Быстрый старт

### Способ 1: Интерактивный режим (рекомендуется)

Просто запустите скрипт и следуйте подсказкам:

```bash
# PowerShell
.\Deploy-Panel.ps1

# или Command Prompt
Deploy-Panel.bat
```

Скрипт попросит:
1. IP адрес сервера
2. Режим развертывания (update / clean-install)
3. Подтверждение перед развертыванием

### Способ 2: С параметрами в строке команды

```bash
# PowerShell
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "update"

# или Command Prompt
Deploy-Panel.bat 192.168.1.100 update
```

## Варианты использования

### Сценарий 1: Обновление существующей установки

```bash
# Интерактивно
.\Deploy-Panel.ps1

# С параметрами
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "update"
```

**Результат:** Обновляет Docker образы и перезапускает сервис, сохраняя все данные.

### Сценарий 2: Чистая переустановка

```bash
# Интерактивно
.\Deploy-Panel.ps1

# С параметрами
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "clean-install"
```

**Результат:** Удаляет все контейнеры, данные и переустанавливает с нуля.

### Сценарий 3: Использование конкретного SSH ключа

```powershell
.\Deploy-Panel.ps1 `
    -ServerIP "192.168.1.100" `
    -Mode "update" `
    -SSHKey "C:\Users\YourUser\.ssh\custom_key"
```

### Сценарий 4: Подключение через нестандартный порт

```powershell
.\Deploy-Panel.ps1 `
    -ServerIP "192.168.1.100" `
    -Mode "update" `
    -SSHPort 2222
```

### Сценарий 5: Подключение от другого пользователя

```powershell
.\Deploy-Panel.ps1 `
    -ServerIP "192.168.1.100" `
    -Mode "update" `
    -User "deploy"
```

## Режимы развертывания

### `update` (Обновление)

```
Использование: Для обновления существующей установки
Действия:
  ✓ Не удаляет контейнеры
  ✓ Не удаляет данные
  ✓ Скачивает новые Docker образы
  ✓ Перезапускает сервис
  
Когда использовать:
  - Обновление кода приложения
  - Обновление зависимостей
  - Исправление ошибок
  - Обновление конфигурации
```

### `clean-install` (Чистая установка)

```
Использование: Для полной переустановки
Действия:
  ✗ Удаляет все контейнеры
  ✗ Удаляет всю persisted data (/service/state)
  ✗ Удаляет файлы конфигурации (.env)
  ✓ Переустанавливает с нуля
  
Когда использовать:
  - Первоначальная установка
  - Полный reset системы
  - Решение проблем с corrupted данными
  
⚠️ ВНИМАНИЕ: Все данные будут удалены!
```

## Параметры скрипта

### PowerShell параметры:

| Параметр | Описание | По умолчанию |
|----------|---------|--------------|
| `-ServerIP` | IP адрес сервера | (запрос пользователя) |
| `-Mode` | Режим: `update` или `clean-install` | (запрос пользователя) |
| `-SSHKey` | Путь к SSH private key | (auto-detect) |
| `-SSHPort` | SSH порт | 22 |
| `-User` | SSH пользователь | root |

### Примеры:

```powershell
# Все параметры указаны в строке
.\Deploy-Panel.ps1 `
    -ServerIP "192.168.1.100" `
    -Mode "update" `
    -SSHKey "C:\Users\Admin\.ssh\id_rsa" `
    -SSHPort 2222 `
    -User "deploy"

# Интерактивный режим (минимум параметров)
.\Deploy-Panel.ps1

# Только сервер указан
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100"
```

## Решение проблем

### Проблема: "ssh: command not found"

**Решение:** Установите SSH клиент
- Windows 10+: SSH встроен, используйте PowerShell
- Старые версии: Установите [Git Bash](https://git-scm.com/download/win) или [PuTTY](https://www.putty.org/)

### Проблема: "Permission denied (publickey)"

**Решение:**
1. Проверьте, правильный ли SSH ключ
2. Проверьте права доступа к ключу
3. Убедитесь, что public key на сервере в `~/.ssh/authorized_keys`

```bash
# На сервере (Linux SSH):
ssh-keygen -y -f C:\Users\Admin\.ssh\id_rsa >> ~/.ssh/authorized_keys
```

### Проблема: "Connection refused"

**Решение:**
1. Проверьте IP адрес сервера
2. Проверьте, открыт ли SSH порт на сервере
3. Проверьте firewall правила

```powershell
# На Windows - проверить доступность сервера
Test-NetConnection -ComputerName "192.168.1.100" -Port 22

# На Windows - проверьте SSH подключение явно
ssh -v -p 22 -i "C:\Users\Admin\.ssh\id_rsa" root@192.168.1.100
```

### Проблема: "/opt/awg-api directory not found"

**Решение:** Используйте режим `clean-install` или скопируйте проект на сервер

```bash
# Вариант 1: Режим чистой установки (если проект будет клонирован)
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "clean-install"

# Вариант 2: Скопировать проект на сервер вручную
scp -r "C:\path\to\MAX" root@192.168.1.100:/opt/awg-api
```

### Проблема: Docker ошибки при развертывании

**Решение:** Проверьте логи

```bash
# На Windows - просмотр логов на сервере
ssh root@192.168.1.100 "docker logs -f awg-api"

# Или напрямую на сервере
docker logs -f awg-api
docker ps -a
```

### Проблема: PowerShell ошибка "cannot be loaded because running scripts is disabled"

**Решение:** 
```powershell
# Выполнить один раз в PowerShell (администратор):
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Или использовать batch файл вместо PowerShell:
Deploy-Panel.bat 192.168.1.100 update
```

## Сценарий полной настройки

### 1. Подготовка Windows машины

```powershell
# Установить ExecutionPolicy (один раз)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Проверить SSH
ssh -V

# Проверить доступность сервера
Test-NetConnection -ComputerName "192.168.1.100" -Port 22
```

### 2. Подготовка SSH ключа

```powershell
# Если нет ключа, создать:
ssh-keygen -t ed25519 -f "$env:USERPROFILE\.ssh\id_ed25519" -N ""

# Скопировать public key на сервер:
# (Нужен пароль сервера или предварительное копирование)
cat $env:USERPROFILE\.ssh\id_ed25519.pub | ssh root@192.168.1.100 "mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys"
```

### 3. Развертывание

```powershell
# Базовое развертывание (интерактивный режим)
.\Deploy-Panel.ps1

# Или с параметрами
.\Deploy-Panel.ps1 -ServerIP "192.168.1.100" -Mode "update"
```

### 4. Проверка

```bash
# Проверить статус панели
curl http://192.168.1.100:8000/health

# Проверить логи
ssh root@192.168.1.100 "docker logs -f awg-api"

# Проверить запущенные контейнеры
ssh root@192.168.1.100 "docker ps"
```

## Дополнительные команды

### Удаленное управление (на Windows в PowerShell)

```powershell
$Server = "192.168.1.100"

# Статус контейнера
ssh root@$Server "docker ps"

# Логи
ssh root@$Server "docker logs awg-api"

# Перезапуск панели
ssh root@$Server "docker restart awg-api"

# Остановка
ssh root@$Server "docker stop awg-api"

# Запуск
ssh root@$Server "docker start awg-api"
```

## Заметки безопасности

- **SSH ключ:** Храните приватный ключ в безопасном месте
- **Пароли:** Никогда не передавайте пароль сервера в скрипте
- **Backup:** Перед `clean-install` сделайте backup `/opt/awg-api/state`
- **Firewall:** Ограничьте доступ к SSH порту только необходимыми IP

## Автоматизация (опционально)

### Windows Task Scheduler

```powershell
# Создать задачу для регулярного обновления
$Action = New-ScheduledTaskAction -Execute "C:\git\MAX\Deploy-Panel.bat" `
    -Argument "192.168.1.100 update"
$Trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At 3AM
Register-ScheduledTask -Action $Action -Trigger $Trigger -TaskName "DeployPanel" `
    -Description "Weekly panel update"
```

---

**Автор:** Deploy Panel Script Generator  
**Версия:** 1.0  
**Последнее обновление:** 2026
