#!/usr/bin/env bash
# setup.sh - Interactive installation script for AWG API
# Supports: Master panel, Local node, Remote node installation
# Features: Configuration validation, Progress tracking, Error handling

set -euo pipefail

# ============================================================================
# CONFIGURATION
# ============================================================================
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMPOSE_FILE="$PROJECT_DIR/docker/docker-compose.yml"
REMOTE_DIR="/opt/awg-api"
CONFIG_DIR="/etc/awg-api"
STATE_DIR="/var/lib/awg-api"
LOG_FILE="/var/log/awg-api-setup.log"
SSH_KEY_DEFAULT=".ssh-live/amnezia_live"
SSH_KNOWN_DEFAULT=".ssh-live/known_hosts"
KNOWN_HOST_IP="5.101.82.46"

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

log() {
  echo -e "${BLUE}[*]${NC} $*" | tee -a "$LOG_FILE"
}

success() {
  echo -e "${GREEN}[+]${NC} $*" | tee -a "$LOG_FILE"
}

error() {
  echo -e "${RED}[-]${NC} $*" | tee -a "$LOG_FILE" >&2
}

warning() {
  echo -e "${YELLOW}[!]${NC} $*" | tee -a "$LOG_FILE"
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    error "Required command not found: $1"
    exit 1
  }
}

has_compose() {
  command -v docker-compose >/dev/null 2>&1 || docker compose version >/dev/null 2>&1
}

compose_cmd() {
  if command -v docker-compose >/dev/null 2>&1; then
    docker-compose -f "$COMPOSE_FILE" "$@"
  else
    docker compose -f "$COMPOSE_FILE" "$@"
  fi
}

is_ipv4() {
  local ip="$1"
  [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || return 1
  local IFS='.'
  read -r o1 o2 o3 o4 <<<"$ip"
  for o in "$o1" "$o2" "$o3" "$o4"; do
    (( o >= 0 && o <= 255 )) || return 1
  done
}

is_port_valid() {
  local port="$1"
  [[ "$port" =~ ^[0-9]+$ ]] && (( port >= 1 && port <= 65535 ))
}

prompt_nonempty() {
  local label="$1"
  local default="${2:-}"
  local val=""
  while [ -z "$val" ]; do
    if [ -n "$default" ]; then
      read -r -p "$label [$default]: " val
      val="${val:-$default}"
    else
      read -r -p "$label: " val
    fi
  done
  printf '%s' "$val"
}

prompt_with_default() {
  local label="$1"
  local default="$2"
  local val=""
  read -r -p "$label [$default]: " val
  printf '%s' "${val:-$default}"
}

prompt_ipv4() {
  local label="$1"
  local ip=""
  while ! is_ipv4 "$ip"; do
    read -r -p "$label: " ip
    if ! is_ipv4 "$ip"; then
      error "Invalid IPv4 address. Try again."
    fi
  done
  printf '%s' "$ip"
}

prompt_port() {
  local label="$1"
  local default="$2"
  local port=""
  while ! is_port_valid "$port"; do
    read -r -p "$label [$default]: " port
    port="${port:-$default}"
    if ! is_port_valid "$port"; then
      error "Invalid port number (1-65535). Try again."
    fi
  done
  printf '%s' "$port"
}

# ============================================================================
# INSTALLATION FUNCTIONS
# ============================================================================

check_prerequisites_local() {
  log "Checking prerequisites..."
  require_cmd docker
  has_compose || {
    error "Required command not found: docker compose (plugin) or docker-compose"
    exit 1
  }
  [ -f "$COMPOSE_FILE" ] || {
    error "Compose file not found: $COMPOSE_FILE"
    exit 1
  }
  success "All prerequisites met"
}

check_prerequisites_remote() {
  log "Checking remote prerequisites via SSH..."
  local output
  output=$(ssh -o ConnectTimeout=5 "$SSH_USER@$SSH_HOST" \
    "command -v docker >/dev/null 2>&1 && (command -v docker-compose >/dev/null 2>&1 || docker compose version >/dev/null 2>&1) && echo 'OK'" 2>&1) || {
    error "Cannot connect to remote server or missing prerequisites"
    return 1
  }
  success "Remote prerequisites verified"
}

generate_env_file() {
  local role="$1"
  local master_ip="${2:-}"
  local api_key="${3:-$(openssl rand -base64 32)}"
  local allowed_ip="${4:-}"
  local dns="${5:-1.1.1.1}"
  local public_ip="${6:-$KNOWN_HOST_IP}"

  cat > .env <<EOF
# AWG API Configuration
AWG_ROLE=${role}
AWG_API_KEY=${api_key}
AWG_SERVER_HOST=${public_ip}
AWG_ALLOWED_IPS=${allowed_ip}
AWG_CONTAINER_NAME=amnezia-awg2
AWG_MODE=auto
AWG_CONF_PATH=/opt/amnezia/awg/awg0.conf
AWG_CLIENTS_TABLE_PATH=/opt/amnezia/awg/clientsTable
AWG_PSK_KEY_PATH=/opt/amnezia/awg/wireguard_psk.key
AWG_SERVER_PUBKEY_PATH=/opt/amnezia/awg/wireguard_server_public_key.key
AWG_DNS=${dns}
AWG_DOCKER_SOCKET=unix:///var/run/docker.sock
AWG_GRPC_PORT=50051
AWG_BOOTSTRAP_ENABLED=true
AWG_BOOTSTRAP_PATH=/node/bootstrap
AWG_STATE_DIR=/service/state
AWG_CA_CERT_PATH=/service/state/pki/ca.crt
AWG_CA_KEY_PATH=/service/state/pki/ca.key
AWG_MASTER_CERT_PATH=/service/state/pki/master.crt
AWG_MASTER_KEY_PATH=/service/state/pki/master.key
AWG_NODE_CERT_PATH=/service/state/pki/node.crt
AWG_NODE_KEY_PATH=/service/state/pki/node.key
AWG_NODE_ID_FILE=/service/state/node_id
AWG_NODE_REGISTRY_FILE=/service/state/nodes.json
EOF

  if [ "$role" = "node" ]; then
    echo "AWG_MASTER_IP=${master_ip}" >> .env
  fi
}

install_master_local() {
  log "Installing Master (Panel) locally..."
  
  check_prerequisites_local
  
  local allowed_ip
  allowed_ip=$(prompt_ipv4 "Allowed caller IPv4 (your IP or 0.0.0.0 for any)")
  
  local public_ip
  public_ip=$(prompt_with_default "Public IP for clients" "$KNOWN_HOST_IP")
  
  local dns
  dns=$(prompt_with_default "DNS for clients" "1.1.1.1")
  
  local api_key
  api_key=$(openssl rand -base64 32)
  
  log "Generating configuration..."
  generate_env_file "master" "" "$api_key" "$allowed_ip" "$dns" "$public_ip"
  
  log "Building Docker image..."
  compose_cmd build

  log "Starting containers..."
  compose_cmd up -d
  
  log "Waiting for API to be ready..."
  for i in {1..30}; do
    if curl -s http://127.0.0.1:8000/health >/dev/null 2>&1; then
      success "API is ready"
      break
    fi
    if [ $i -eq 30 ]; then
      error "API failed to start. Check logs: compose_cmd logs"
      return 1
    fi
    sleep 2
  done
  
  success "Master installation complete!"
  echo ""
  echo "=============== Installation Summary ==============="
  echo "Role: Master (Web Panel)"
  echo "API URL: http://127.0.0.1:8000"
  echo "API Key: $api_key"
  echo "Public IP: $public_ip"
  echo "Allowed IPs: $allowed_ip"
  echo "DNS: $dns"
  echo "=================================================="
  echo ""
  echo "Next steps:"
  echo "  1. Open http://127.0.0.1:8000 in your browser"
  echo "  2. Install nodes using: ./setup.sh"
  echo "  3. Connect nodes from the panel"
}

install_node_local() {
  log "Installing Node (Local) ..."
  
  check_prerequisites_local
  
  local master_ip
  master_ip=$(prompt_ipv4 "Master IP address")
  
  local master_port
  master_port=$(prompt_port "Master API port" "8000")
  
  local allowed_ip
  allowed_ip=$(prompt_ipv4 "Allowed caller IPv4")
  
  local dns
  dns=$(prompt_with_default "DNS for clients" "1.1.1.1")
  
  local api_key
  api_key=$(openssl rand -base64 32)
  
  log "Generating configuration..."
  generate_env_file "node" "$master_ip" "$api_key" "$allowed_ip" "$dns"
  
  log "Building Docker image..."
  compose_cmd build
  
  log "Starting containers..."
  compose_cmd up -d
  
  log "Waiting for API to be ready..."
  for i in {1..30}; do
    if curl -s http://127.0.0.1:8000/health >/dev/null 2>&1; then
      success "API is ready"
      break
    fi
    if [ $i -eq 30 ]; then
      error "API failed to start. Check logs: compose_cmd logs"
      return 1
    fi
    sleep 2
  done
  
  success "Node local installation complete!"
  echo ""
  echo "=============== Installation Summary ==============="
  echo "Role: Node (Local)"
  echo "Master IP: $master_ip"
  echo "Master Port: $master_port"
  echo "API URL: http://127.0.0.1:8000"
  echo "API Key: $api_key"
  echo "=================================================="
  echo ""
  echo "Next steps:"
  echo "  1. Go to Master panel: http://$master_ip:$master_port"
  echo "  2. Add this node: IP=$(hostname -I | awk '{print $1}'), Port=8000"
  echo "  3. Click 'Connect node API'"
}

install_node_remote() {
  log "Installing Node (Remote) ..."
  
  require_cmd ssh
  require_cmd scp
  
  # Get SSH connection details
  local ssh_host
  ssh_host=$(prompt_nonempty "Remote SSH server IP or hostname")
  
  local ssh_user
  ssh_user=$(prompt_with_default "SSH user" "root")
  
  local ssh_port
  ssh_port=$(prompt_port "SSH port" "22")
  
  local ssh_key
  ssh_key=$(prompt_with_default "SSH private key path" "$SSH_KEY_DEFAULT")
  
  if [ ! -f "$ssh_key" ]; then
    error "SSH key not found: $ssh_key"
    return 1
  fi
  
  # Test SSH connection
  log "Testing SSH connection..."
  if ! ssh -o ConnectTimeout=5 -p "$ssh_port" -i "$ssh_key" "$ssh_user@$ssh_host" \
    "echo 'SSH connection OK'" >/dev/null 2>&1; then
    error "Cannot connect to remote server"
    return 1
  fi
  success "SSH connection established"
  
  # Get installation parameters
  local master_ip
  master_ip=$(prompt_ipv4 "Master IP address")
  
  local master_port
  master_port=$(prompt_port "Master API port" "8000")
  
  local allowed_ip
  allowed_ip=$(prompt_ipv4 "Allowed caller IPv4 (usually master IP)")
  
  local dns
  dns=$(prompt_with_default "DNS for clients" "1.1.1.1")
  
  local public_ip
  public_ip=$(prompt_with_default "Node public IP for clients" "$ssh_host")
  
  local api_key
  api_key=$(openssl rand -base64 32)
  
  log "Preparing installation files..."

  # Create temp directory on remote
  log "Creating remote directories..."
  ssh -p "$ssh_port" -i "$ssh_key" "$ssh_user@$ssh_host" \
    "mkdir -p ${REMOTE_DIR} && mkdir -p ${STATE_DIR}"
  
  # Copy files to remote
  log "Uploading files..."
  scp -P "$ssh_port" -i "$ssh_key" -r \
    app docker scripts requirements.txt .env.example README.md \
    "$ssh_user@$ssh_host:${REMOTE_DIR}/"
  
  success "Files uploaded"

  # Install/start node on remote using shared installer
  log "Running unified remote node installer..."
  ssh -p "$ssh_port" -i "$ssh_key" "$ssh_user@$ssh_host" bash <<REMOTE
set -euo pipefail
chmod +x "${REMOTE_DIR}/scripts/install_node_remote.sh"
bash "${REMOTE_DIR}/scripts/install_node_remote.sh" \
  --master-ip "${master_ip}" \
  --master-port "${master_port}" \
  --allowed-ip "${allowed_ip}" \
  --public-ip "${public_ip}" \
  --dns "${dns}" \
  --api-key "${api_key}" \
  --target-dir "${REMOTE_DIR}"
REMOTE
  
  log "Waiting for remote API to be ready..."
  for i in {1..30}; do
    if ssh -p "$ssh_port" -i "$ssh_key" "$ssh_user@$ssh_host" \
      "curl -s http://127.0.0.1:8000/health >/dev/null 2>&1" 2>/dev/null; then
      success "Remote API is ready"
      break
    fi
    if [ $i -eq 30 ]; then
      error "Remote API failed to start. Check remote logs:"
      echo "  ssh -p $ssh_port -i $ssh_key $ssh_user@$ssh_host 'cd $REMOTE_DIR && docker compose -f docker/docker-compose.yml logs'"
      return 1
    fi
    sleep 2
  done
  
  success "Remote node installation complete!"

  log "Attempting automatic bootstrap enrollment on master..."
  local enrolled="false"
  for i in {1..20}; do
    if curl -fsS -X POST "http://${master_ip}:${master_port}/panel/register-node?target=${public_ip}&force=true" >/dev/null 2>&1; then
      enrolled="true"
      success "Node bootstrap enrollment completed (attempt $i/20)"
      break
    fi
    sleep 3
  done
  if [ "$enrolled" != "true" ]; then
    warning "Auto bootstrap enrollment failed after retries. You can retry from panel: Connect node API"
  fi

  echo ""
  echo "=============== Installation Summary ==============="
  echo "Role: Node (Remote)"
  echo "Remote Server: $ssh_user@$ssh_host:$ssh_port"
  echo "Master IP: $master_ip"
  echo "Master Port: $master_port"
  echo "Node Public IP: $public_ip"
  echo "API URL: http://$public_ip:8000"
  echo "API Key: $api_key"
  echo "=================================================="
  echo ""
  echo "Next steps:"
  echo "  1. Go to Master panel: http://$master_ip:$master_port"
  echo "  2. Add node: IP=$public_ip, Port=8000"
  echo "  3. Click 'Connect node API'"
  echo ""
  echo "Useful commands:"
  echo "  View logs: ssh -p $ssh_port -i $ssh_key $ssh_user@$ssh_host 'cd $REMOTE_DIR && docker compose -f docker/docker-compose.yml logs -f'"
  echo "  Check health: curl http://$public_ip:8000/health"
  echo "  Restart: ssh -p $ssh_port -i $ssh_key $ssh_user@$ssh_host 'cd $REMOTE_DIR && docker compose -f docker/docker-compose.yml restart'"
}

show_menu() {
  clear
  echo ""
  echo "╔════════════════════════════════════════════════════╗"
  echo "║         AWG API Installation Wizard               ║"
  echo "╚════════════════════════════════════════════════════╝"
  echo ""
  echo "Select installation type:"
  echo ""
  echo "  1) Install Master (Web Panel) - Local"
  echo "  2) Install Node - Local"
  echo "  3) Install Node - Remote (via SSH)"
  echo "  4) Show status (docker compose)"
  echo "  5) View logs"
  echo "  6) Stop services"
  echo "  7) Exit"
  echo ""
  read -r -p "Enter choice [1-7]: " choice
}

main() {
  log "Starting AWG API Setup Wizard"
  
  # Initialize log file
  mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
  touch "$LOG_FILE"
  
  cd "$PROJECT_DIR"
  
  while true; do
    show_menu
    
    case "$choice" in
      1)
        install_master_local || warning "Master installation failed"
        read -r -p "Press Enter to continue..."
        ;;
      2)
        install_node_local || warning "Local node installation failed"
        read -r -p "Press Enter to continue..."
        ;;
      3)
        install_node_remote || warning "Remote node installation failed"
        read -r -p "Press Enter to continue..."
        ;;
      4)
        log "Showing service status..."
        compose_cmd ps
        read -r -p "Press Enter to continue..."
        ;;
      5)
        log "Showing logs (last 50 lines, press Ctrl+C to exit)..."
        compose_cmd logs --tail=50 -f || true
        ;;
      6)
        log "Stopping services..."
        compose_cmd down
        success "Services stopped"
        read -r -p "Press Enter to continue..."
        ;;
      7)
        log "Exiting setup wizard"
        exit 0
        ;;
      *)
        error "Invalid choice. Try again."
        sleep 1
        ;;
    esac
  done
}

main "$@"
