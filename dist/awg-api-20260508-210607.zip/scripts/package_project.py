#!/usr/bin/env python3
"""Create a deployment ZIP archive for the AWG API project."""

from __future__ import annotations

import argparse
import fnmatch
import os
from datetime import datetime
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

EXCLUDE_ROOTS = {
    ".git",
    ".venv",
    "venv",
    "dist",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
}

EXCLUDE_FILE_PATTERNS = {
    "*.pyc",
    "*.pyo",
    "*.pyd",
    "*.log",
    "*.tmp",
    "*.bak",
}

REQUIRED_ARCHIVE_PATHS = {
    "app/main.py",
    "docker/Dockerfile",
    "docker/docker-compose.yml",
    "scripts/install_from_zip.sh",
    "scripts/install_project.sh",
    "scripts/install_node_remote.sh",
    "requirements.txt",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Package project into zip for server upload"
    )
    parser.add_argument("--output-dir", default="dist", help="Output folder")
    parser.add_argument(
        "--archive-name",
        default="",
        help="Archive name (with or without .zip extension)",
    )
    parser.add_argument(
        "--include-secrets",
        action="store_true",
        help="Include .ssh-live directory in archive",
    )
    parser.add_argument(
        "--open-output",
        action="store_true",
        help="Open output directory after packaging (Windows)",
    )
    return parser.parse_args()


def should_skip(relative_posix: str, include_secrets: bool) -> bool:
    parts = Path(relative_posix).parts
    blocked_roots = set(EXCLUDE_ROOTS)
    if include_secrets:
        blocked_roots.discard(".ssh-live")
    else:
        blocked_roots.add(".ssh-live")

    if parts and parts[0] in blocked_roots:
        return True

    filename = Path(relative_posix).name
    for pattern in EXCLUDE_FILE_PATTERNS:
        if fnmatch.fnmatch(filename, pattern):
            return True
    return False


def build_archive(project_root: Path, output_path: Path, include_secrets: bool) -> int:
    entries = 0
    with ZipFile(output_path, "w", compression=ZIP_DEFLATED) as zf:
        for source in project_root.rglob("*"):
            if source.is_dir():
                continue
            rel = source.relative_to(project_root).as_posix()
            if should_skip(rel, include_secrets):
                continue
            zf.write(source, rel)
            entries += 1
    return entries


def validate_archive(output_path: Path) -> None:
    with ZipFile(output_path, "r") as zf:
        archive_entries = set(zf.namelist())
    missing = sorted(path for path in REQUIRED_ARCHIVE_PATHS if path not in archive_entries)
    if missing:
        missing_str = ", ".join(missing)
        raise RuntimeError(f"Archive validation failed. Missing required files: {missing_str}")


def main() -> int:
    args = parse_args()

    script_dir = Path(__file__).resolve().parent
    project_root = script_dir.parent
    output_dir = (project_root / args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    if args.archive_name:
        archive_name = args.archive_name
    else:
        archive_name = f"awg-api-{datetime.now().strftime('%Y%m%d-%H%M%S')}"

    if not archive_name.lower().endswith(".zip"):
        archive_name += ".zip"

    archive_path = output_dir / archive_name

    print(f"Project root: {project_root}")
    print(f"Output zip : {archive_path}")

    entries = build_archive(project_root, archive_path, args.include_secrets)
    validate_archive(archive_path)

    print("\nArchive created successfully:", archive_path)
    print(f"Files packed: {entries}")
    print("Archive validation: OK")

    if args.open_output and os.name == "nt":
        os.startfile(str(output_dir))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
