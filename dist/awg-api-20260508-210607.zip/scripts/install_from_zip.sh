#!/usr/bin/env bash
# install_from_zip.sh - unpack project zip and invoke scripts/install_project.sh.
set -euo pipefail

TARGET_DIR="/opt/awg-api"
ZIP_PATH=""
SKIP_BUILD="false"
INSTALL_MODE="update"

usage() {
  cat <<EOF
Usage: $0 --zip /path/to/archive.zip [--target-dir /opt/awg-api] [--skip-build] [--mode update|clean-reinstall]

Options:
  --zip PATH         Path to uploaded project zip (required)
  --target-dir PATH  Install path on server (default: /opt/awg-api)
  --skip-build       Do not run docker compose up -d --build
  --mode MODE        Install mode: update (default) or clean-reinstall
  -h, --help         Show this help
EOF
}

detect_pkg_manager() {
  if command -v apt-get >/dev/null 2>&1; then
    echo "apt"
  elif command -v dnf >/dev/null 2>&1; then
    echo "dnf"
  elif command -v yum >/dev/null 2>&1; then
    echo "yum"
  else
    echo ""
  fi
}

install_pkgs() {
  local pm="$1"
  shift
  local pkgs=("$@")

  case "$pm" in
    apt)
      DEBIAN_FRONTEND=noninteractive apt-get update -y
      DEBIAN_FRONTEND=noninteractive apt-get install -y "${pkgs[@]}"
      ;;
    dnf)
      dnf install -y "${pkgs[@]}"
      ;;
    yum)
      yum install -y "${pkgs[@]}"
      ;;
    *)
      echo "ERROR: no supported package manager found to install: ${pkgs[*]}" >&2
      exit 1
      ;;
  esac
}

ensure_unzip() {
  if command -v unzip >/dev/null 2>&1; then
    echo "==> unzip already installed"
    return
  fi
  echo "==> Installing unzip"
  install_pkgs "$(detect_pkg_manager)" unzip
}


while [ $# -gt 0 ]; do
  case "$1" in
    --zip)
      ZIP_PATH="${2:-}"
      shift 2
      ;;
    --target-dir)
      TARGET_DIR="${2:-}"
      shift 2
      ;;
    --skip-build)
      SKIP_BUILD="true"
      shift
      ;;
    --mode)
      INSTALL_MODE="${2:-}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

case "$INSTALL_MODE" in
  update|clean-reinstall)
    ;;
  *)
    echo "ERROR: invalid --mode '$INSTALL_MODE'. Expected: update|clean-reinstall" >&2
    exit 1
    ;;
esac

if [ -z "$ZIP_PATH" ]; then
  echo "ERROR: --zip is required" >&2
  usage
  exit 1
fi

if [ ! -f "$ZIP_PATH" ]; then
  echo "ERROR: zip file not found: $ZIP_PATH" >&2
  exit 1
fi

ensure_unzip

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

echo "==> Unpacking zip: $ZIP_PATH"
unzip -q "$ZIP_PATH" -d "$TMP_DIR"

if [ ! -d "$TMP_DIR/app" ] || [ ! -f "$TMP_DIR/requirements.txt" ]; then
  echo "ERROR: zip does not look like project root (missing app/ or requirements.txt)" >&2
  exit 1
fi

echo "==> Installing files to: $TARGET_DIR"
mkdir -p "$TARGET_DIR"

ENV_BACKUP=""
STATE_BACKUP=""
if [ "$INSTALL_MODE" = "update" ]; then
  if [ -f "$TARGET_DIR/.env" ]; then
    ENV_BACKUP="$(mktemp)"
    cp "$TARGET_DIR/.env" "$ENV_BACKUP"
  fi
  if [ -d "$TARGET_DIR/state" ]; then
    STATE_BACKUP="$(mktemp -d)"
    cp -a "$TARGET_DIR/state" "$STATE_BACKUP/"
  fi
fi

if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete \
    --exclude '.env' \
    --exclude 'state/' \
    "$TMP_DIR"/ "$TARGET_DIR"/
else
  find "$TARGET_DIR" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
  cp -a "$TMP_DIR"/. "$TARGET_DIR"/
fi

if [ "$INSTALL_MODE" = "update" ]; then
  if [ -n "$ENV_BACKUP" ] && [ -f "$ENV_BACKUP" ]; then
    cp "$ENV_BACKUP" "$TARGET_DIR/.env"
  fi
  if [ -n "$STATE_BACKUP" ] && [ -d "$STATE_BACKUP/state" ]; then
    rm -rf "$TARGET_DIR/state"
    cp -a "$STATE_BACKUP/state" "$TARGET_DIR/state"
  fi
fi

PROJECT_INSTALLER="$TARGET_DIR/scripts/install_project.sh"
if [ ! -f "$PROJECT_INSTALLER" ]; then
  echo "ERROR: project installer not found: $PROJECT_INSTALLER" >&2
  exit 1
fi

chmod +x "$PROJECT_INSTALLER"

echo "==> Running project installer"
if [ "$SKIP_BUILD" = "true" ]; then
  bash "$PROJECT_INSTALLER" --project-dir "$TARGET_DIR" --mode "$INSTALL_MODE" --skip-build
else
  bash "$PROJECT_INSTALLER" --project-dir "$TARGET_DIR" --mode "$INSTALL_MODE"
fi
