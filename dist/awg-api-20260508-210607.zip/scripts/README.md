# AWG API Installation Scripts

Для удобной установки используйте **единый публичный скрипт `../setup.sh`**.
Скрипты в этой папке — внутренние детали реализации.

## 🚀 Быстрый старт

```bash
chmod +x ../setup.sh
../setup.sh
```

Выберите нужный вариант из меню.

---

## 📦 ZIP упаковка + установка на сервере

Для сценария "упаковать одним кликом -> передать на сервер -> распаковать и установить":

`install_from_zip.sh` — внутренняя обертка: распаковывает архив и вызывает основной установщик проекта.

### 1) Упаковать проект в ZIP (Windows)

```powershell
python scripts/package_project.py
```

Архив создается в `dist/` (например `dist/awg-api-20260413-143001.zip`).

Опции:

```powershell
# свое имя архива
python scripts/package_project.py --archive-name awg-api-release

# включить .ssh-live в архив (по умолчанию исключается)
python scripts/package_project.py --include-secrets
```

### 2) Передать архив на сервер

```bash
scp dist/awg-api-*.zip root@<SERVER_IP>:/tmp/
scp scripts/install_from_zip.sh root@<SERVER_IP>:/tmp/
```

### 3) Распаковать и установить на сервере

```bash
ssh root@<SERVER_IP>
cd /opt/awg-api
bash ./setup.sh from-zip --zip /tmp/awg-api-20260413-143001.zip
```

Если скрипт уже загружен вместе с проектом, можно запускать так:

```bash
bash /opt/awg-api/scripts/install_from_zip.sh --zip /tmp/awg-api-20260413-143001.zip
```

Полезные флаги:

```bash
# установить в другой каталог
bash scripts/install_from_zip.sh --zip /tmp/awg-api.zip --target-dir /srv/awg-api

# только распаковка без docker compose up -d --build
bash scripts/install_from_zip.sh --zip /tmp/awg-api.zip --skip-build

# безопасное обновление панели (сохраняет .env и state/)
bash scripts/install_from_zip.sh --zip /tmp/awg-api.zip --mode update

# чистая переустановка (очистка state/ и runtime env)
bash scripts/install_from_zip.sh --zip /tmp/awg-api.zip --mode clean-reinstall
```

---

## 📋 Доступные режимы

### 1️⃣ **setup.sh** (РЕКОМЕНДУЕТСЯ)

Интерактивный скрипт с полной поддержкой всех режимов установки.

#### Меню:
```
1) Install Master (Web Panel) - Local
2) Install Node - Local
3) Install Node - Remote (via SSH)
4) Show status (docker-compose)
5) View logs
6) Stop services
7) Exit
```

#### Примеры использования:

**Master (Локальная панель):**
```bash
./setup.sh
# Выберите: 1
# Введите: Allowed IP, Public IP, DNS
```

**Node (Локальный узел):**
```bash
./setup.sh
# Выберите: 2
# Введите: Master IP, Port, Allowed IP, DNS
```

**Node (Удаленный через SSH):**
```bash
./setup.sh
# Выберите: 3
# Введите: SSH host/port/user/key, Master IP, Node public IP
```

---

### 2️⃣ **install_node_remote.sh** (единый источник для remote-node)

Скрипт удаленной установки Node в non-interactive режиме.

Используется в двух местах:
- `setup.sh` (пункт 3 Install Node - Remote)
- Web panel (auto-install по SSH)

#### Синтаксис:
```bash
bash scripts/install_node_remote.sh \
     --master-ip 192.168.1.10 \
     --allowed-ip 192.168.1.10 \
     --public-ip 192.168.1.50 \
     --master-port 8000 \
     --dns 1.1.1.1 \
     --target-dir /opt/awg-api
```

---

## 🛠️ Дополнительные утилиты

### Проверка статуса
```bash
./setup.sh  # Пункт 4
# или
docker-compose ps
```

### Просмотр логов
```bash
./setup.sh  # Пункт 5
# или
docker-compose logs -f awg-api
```

### Остановка/перезагрузка
```bash
./setup.sh  # Пункт 6 для остановки
# или
docker-compose restart
docker-compose down
```

---

## 📚 Архитектура

```
┌─────────────────────────────┐
│   Master (Панель)          │
│  ├─ REST API :8000         │
│  ├─ gRPC :50051            │
│  └─ PKI (Сертификаты)      │
└─────────────────────────────┘
         │
    gRPC+mTLS
         │
    ┌────┴────┬─────────┐
    │          │         │
┌──────┐  ┌──────┐  ┌──────┐
│Node1 │  │Node2 │  │Node3 │ (Удаленные)
│:8000 │  │:8000 │  │:8000 │
└──────┘  └──────┘  └──────┘
```

---

## 🔐 Переменные окружения (.env)

Все переменные генерируются автоматически. Основные:

```env
AWG_ROLE=master              # или node
AWG_API_KEY=...              # Автогенерируется (base64)
AWG_SERVER_HOST=5.101.82.46  # Публичный IP
AWG_ALLOWED_IPS=192.168.1.0/24
AWG_MASTER_IP=...            # Для node
AWG_DNS=1.1.1.1
AWG_GRPC_PORT=50051
```

---

## ✅ Pre-requisites

**Для локальной установки:**
- Docker 20+
- Docker Compose
- curl
- openssl

**Для удаленной установки (SSH):**
- SSH ключ в `.ssh-live/amnezia_live`
- SSH доступ к хосту
- Docker на удаленном хосте

**На целевом сервере:**
- AmneziaWG контейнер (автоматически управляется)
- Доступ к `/var/run/docker.sock`

---

## 🐛 Troubleshooting

### Скрипт setup.sh не запускается
```bash
chmod +x setup.sh
chmod +x install_project.sh install_node_remote.sh
bash ./setup.sh  # вместо ./setup.sh
```

### Docker контейнер не стартует
```bash
docker-compose logs awg-api
# Проверьте .env файл
cat .env
```

### SSH подключение не работает
```bash
# Проверьте SSH ключ
chmod 600 .ssh-live/amnezia_live
ssh -i .ssh-live/amnezia_live root@<IP> "echo OK"
```

### API не отвечает после установки
```bash
curl http://127.0.0.1:8000/health
# Если 5xx - посмотрите логи:
docker-compose logs awg-api
```

---

## 📖 Подробная документация

Полная документация со скриншотами и примерами: [SETUP_GUIDE.md](../SETUP_GUIDE.md)

---

## 💡 Советы

1. **Master + Node на одной машине?** Запустите Master, потом Node (локальный или удаленный)
2. **Массовая установка?** Используйте `install_node_remote.sh` в Ansible/Terraform/CloudFormation
3. **Backup конфигов?** Используйте `docker volumes backup awg-api-state`
4. **Разные DNS для регионов?** Установите несколько Node с разными DNS

---

## 📝 Логирование

Все события логируются в `/var/log/awg-api-setup.log`

```bash
tail -f /var/log/awg-api-setup.log
```

---

## 📞 Поддержка

Если что-то не работает:
1. Прочитайте логи: `docker-compose logs`
2. Проверьте сетевые настройки: `docker network inspect bridge`
3. Убедитесь в правильности IP адресов и портов
